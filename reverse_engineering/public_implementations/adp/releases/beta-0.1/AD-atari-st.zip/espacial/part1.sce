;---------------------------------------------------------------------------
;---------------------   An UnDAADed game o'hacker   -----------------------
;---------------------------------------------------------------------------
; DAAD Vers. : 2
; Target     : ST (5)
; Language   : Spanish (1)
; BaseAddr   : 0x0000
; Endianness : Little-endian
; Null Word  : _
;---------------------------------------------------------------------------
; Number of objects         : 18
; Number of Locations       : 24
; Number of User Messages   : 97
; Number of System Messages : 166
; Number of Processes       : 24
;---------------------------------------------------------------------------
;                   Memory   File 
; Pointer            Addr   Offset
; =======           ======  ======
; Tokens addr     : 0x01B4  0x01B4
; Procs addr      : 0x4F9C  0x4F9C
; Objs addr       : 0x34EE  0x34EE
; Locs addr       : 0x3F9C  0x3F9C
; UsrMsg addr     : 0x339C  0x339C
; SysMsg addr     : 0x0C0A  0x0C0A
; Connex addr     : 0x401C  0x401C
; Vocabu addr     : 0x005C  0x005C
; InitAt addr     : 0x40A6  0x40A6
; ObjName addr    : 0x404C  0x404C
; Weight/CW addr  : 0x4070  0x4070
; Extra attr addr : 0x4082  0x4082
;---------------------------------------------------------------------------
; File length    : 0x4FCC (20428 bytes)
;---------------------------------------------------------------------------
;
;
/CTL
_
/TOK
_de_
a_de_
_est�
s_de_
_la_
_el_
_te_
_un_
as_
_de
os_
es_
ado
ent
_co
ero
a_
o_
e_
ar
es
er
an
a.
en
al
as
di
,_
or
n_
id
el
ci
nt
ad
s_
".
qu
l_
..
y_
ur
os
o.
re
am
ch
ll
te
pu
�n
on
in
ro
ti
Es
ab
ri
ac
at
t�
tu
mp
gu
ed
:_
av
ir
._
un
ol
ce
su
to
um
ag
ca
tr
is
pi
po
ra
et
om
li
ug
Un
ev
m�
_s
ta
de
us
Ta
_n
la
si
ha
cl
it
mu
vi
!"

se
ez
_l
ob
cu
eb
aj
co
_m
�n
_p
do
lu
ni
bu
ec
le
fi
ig
En
ru
hu
.
;------------------------------------------------------------------------------
/VOC    ;Vocabulary
ABRIR   61      verb
ALMAC   67      verb
ANTIG   2       verb
ARMAR   61      noun
BAJAR   5       verb
BOTAS   63      noun
BOTEL   73      noun
BURBU   74      noun
CASCO   65      noun
CERRA   62      verb
CHIP    77      noun
COGER   59      verb
COMPU   60      noun
COPA    72      noun
DEJAR   60      verb
ENTRA   3       verb
ESCUC   55      verb
ESPER   53      verb
EXAMI   58      verb
FIN     70      verb
GIRO    1       verb
GUANT   67      noun
HABLA   56      verb
INVEN   52      verb
JUGAD   68      verb
LEGIO   69      verb
LLAVE   75      noun
LOADD   52      noun
METER   65      verb
MIRAR   54      verb
MONO    66      noun
OB8     68      noun
OB9     69      noun
PONER   63      verb
PUERT   70      noun
QUITA   64      verb
RAMLO   53      noun
RAMSA   51      noun
SACAR   66      verb
SALID   51      verb
SALIR   4       verb
SAVED   50      noun
SOBRE   76      noun
SUBIR   6       verb
TARJE   71      noun
TODO    49      noun
TRAJE   64      noun
USAR    57      verb
ZAPAT   62      noun
;------------------------------------------------------------------------------
/STX    ;System Messages Texts
/0 
PASA A BAJA RESOLUCION.
/1 
Adem�s hay 
/2 
\r>
/3 
0
/4 
. 
/5 
No hay ning�n sitio donde se pueda meter nada.\r
/6 
La entrop�a del universo aumenta inexorablemente.\r
/7 
No hay ninguna salida.\r
/8 
No puedes 
/9 
Tienes 
/10 
No tienes nada de nada.\r
/11 
Tienes puesto 
/12 
�Seguro? (S/N) 
/13 
Est� cerrada.\r
/14 

/15 
Vale.\r
/16 

/17 
\rTurnos consumidos: 
/18 
No ha lugar.\r
/19 
Tendr�s que quitarte algo antes de ponerte _.\r
/20 
.\r
/21 

/22 

/23 
Se puede poner.\r
/24 
Llevas _.\r
/25 

/26 

/27 
Ya no puedes llevar m�s trastos.\r
/28 
ponerte.\r
/29 
quitarte.\r
/30 
S
/31 
N
/32 
--->
/33 

/34 
abrir nada.\r
/35 
Est� abierto.\r
/36 
Has cogido _.\r
/37 
Te has puesto _.\r
/38 
Te has quitado _.\r
/39 
Has dejado _.\r
/40 
No puedes ponerte _.\r
/41 
No puedes quitarte _.\r
/42 
Llevas demasiadas cosas, no puedes quitarte _.\r
/43 
@ pesa demasiado.\r
/44 
@ est� en 
/45 
sacar.\r
/46 
, 
/47 
 y 
/48 
.\r
/49 
Dentro hay 
/50 
En el bolsillo hay 
/51 
.\r
/52 
coger.\r
/53 
dejar.\r
/54 
hacerlo.\r
/55 
\rNo hay nada para 
/56 
Disco no preparado. Pulsa una tecla para repetir.\r
/57 
Error de entrada/salida.\r
/58 
Disco lleno.\r
/59 
Nombre err�neo.\r
/60 
Nombre del fichero: 
/61 

/62 
Ya lo estaba.\r
/63 
Est� cerrado.\r
/64 
No hay ning�n sitio de donde sacar.\r
/65 
No tienes nada que puedas meter.\r
/66 
mover _.\r
/67 
cerrar nada.\r
/68 
Escuchas los habituales susurros de servomecanismos y supercomputa- doras funcionando. A veces acompa- �ado por el apagado zumbido de al- g�n cohete direccional.\r
/69 
Observas desilusionado que vuelves al feo h�bito del soliloquio.\r
/70 
No hay nada que utilizar.\r
/71 
Est� abierta.\r
/72 
@ 
/73 
no cabe en _.\r
/74 

/75 
Est�s muerto.\r
/76 
         
/77 
\".
/78 
\".\r
/79 
SALIDAS
/80 
INVENTARIO
/81 
ESPERAR
/82 
MIRAR
/83 
ESCUCHAR
/84 
HABLAR
/85 
USAR
/86 
EXAMINAR
/87 
COGER
/88 
DEJAR
/89 
ABRIR
/90 
CERRAR
/91 
PONERSE
/92 
QUITARSE
/93 
METER EN
/94 
SACAR DE
/95 
SAVE/LOAD
/96 
JUGADAS
/97 
ESPACIAL
/98 
FIN JUEGO
/99 
Por el AMUPRO suenan viejos exitos de los Kinky Kippers.\k\bAMUPRO: Ambiente musical programable.\k\bKinky Kippers: grupo revelaci�n de gran �xito en el Sistema Solar entre los siglos XX y XXV, famosos no s�lo por su m�sica sino  tambi�n por sus extravagantes costumbres y su intenso olor a arenque, que no impidi� que fueran el centro de todas las fiestas a las que acudieron en el  periodo antes mencionado.\r
/100 
TODO
/101 
CONTINUAR
/102 
OTRA PART.
/103 
ADIOS
/104 
SAVE DISCO
/105 
SAVE RAM
/106 
LOAD DISCO
/107 
LOAD RAM
/108 
UA-E
/109 
UFAP
/110 
UPI-T
/111 
UPI-CO
/112 
UPM-CO
/113 
UPS-CO
/114 
UPM-T
/115 
UPP-M
/116 

/117 

/118 
UA-S
/119 
TIGA
/120 
RL-B
/121 
RL-C
/122 
UVIR
/123 
MAGOLLA
/124 
PD-AA
/125 
CHAPO
/126 
GIRO
/127 
ANTIGIRO
/128 
ENTRAR
/129 
SALIR
/130 
BAJAR
/131 
SUBIR
/132 
INVI
/133 
A TI MISMO
/134 
A.D.
/135 
MIESINF
/136 
COFRATO
/137 
CORME
/138 
MIESUP
/139 
OPTOLOCK
/140 
PMM
/141 
COMUCOS
/142 
INVI
/143 
HOZOOVIAC
/144 
UTV
/145 
INVI
/146 
CG
/147 
BG
/148 
GRAMAGAL
/149 
CORREAD
/150 
ROMI
/151 
PEAS
/152 
NIFLORES-1
/153 
NIFLORES-2
/154 
URSU
/155 
LECMA
/156 
UTV
/157 
INVI
/158 
UA-V
/159 
INVI
/160 
NIFLORES-3
/161 
NIFLORES-4
/162 
NIFLORES-5
/163 
NIFLORES-6
/164 
NIFLORES-7
/165 
BLOQUEATOR
;------------------------------------------------------------------------------
/MTX    ;Message Texts
/0 
\b\rEsta es la primera parte de la psicod�lica aventura gal�ctica \"La CONGA contra el CELO\", creada por el equipo A.D. en un per�odo de sobredosis.\k\b\rDirecci�n: Andr�s Samudio\rProgramaci�n: Juan Manuel Medina\rGr�ficos 16 bits: J. A. Darder\rGr�ficos 8 bits: Carlos Marqu�s\rCols: Eva Samitier, Tim Gilberts y Juanjo Mu�oz.\k\bSi necesitas ayuda para resolver esta aventura  o cualquier otra, tienes dudas sobre el manejo del P.A.W., deseas tener noticias sobre lo que se cuece en el mundo de la aventura o tener acceso a aventuras exclusivas entonces ponte en contacto con...\k\b\rClub de Aventuras A.D. (C.A.A.D.)\r\rEscribe al Apdo. 319, 46080 de Valencia y obtendr�s cumplida informaci�n sobre el C.A.A.D. y su fanzine.
/1 
Con tus torpes manipulaciones la UVIR explota, decorando el paisaje con tus MUSAVIS.
/2 
Intentas abrir el RL-C, pero est� fuertemente sellado.
/3 
Introduces la MAGOLLA en el lector magn�tico de la UFAP. 
/4 
El mecanismo no se activa.
/5 
Al contacto con la TIGA, el meca- nismo del OPTOLOCK se activa y la UA-S se abre.
/6 
\rLa MAGOLLA ha quedado atascada en el LECMA.
/7 
Acercando la MAGOLLA a las UPI-CO consigues que se desprendan de la pared.
/8 
Lleva un MICROINVI adosado que in- dica que est� 
/9 
magnetizada.
/10 
desmagnetizada.
/11 
De momento es inoperante.
/12 
Alg�n gracioso las ha dejado pega- das magn�ticamente a la pared.
/13 
La UA-E se cierra.
/14 
Un BLOQUEATOR te impide el paso.\rExige identificaci�n.
/15 
Los BLOQUEATORS no platican en vano. Reciben informaci�n y dan �rdenes.
/16 
Al contacto con tu mano, el CHAPO vibra. Sientes un raro cosquilleo.
/17 
Con un suave \"Puff\", el PD-AA se desmoleculariza al penetrar aire en su interior.
/18 
Un CORREMICO sale de la UTV en es- tado de trance y con el UPM-CO a�n humeante. Saluda mec�nicamente y con pasos de zombie se dirige a su ZODE.
/19 
\rEl ROMI dice: UN COSME NO TIENE YA PERMISO PARA DISFRUTAR DE LA ZOES, CAMBIE DE ZONA, POR FAVOR.
/20 
Preguntas al ROMI por tu TIGA. El suele encontrarlo todo.\rLO SIENTO, SE�OR - responde - NO DISPONGO DE DATOS SUFICIENTES PARA CONTESTARLE.
/21 
Das al ROMI tu n�mero de identifi- caci�n. Busca en su banco de datos y dice: ESPERE, POR FAVOR.\k Al poco rato vuelve y te entrega la TIGA extraviada.
/22 
\rDISCULPE, SE�OR. PERO DEBO COLABO- RAR ACTIVAMENTE EN SU CAMBIO DE ZONA - Con estas palabras el ROMI te traslada firmemente fuera de la ZOES.
/23 
Informo al ROMI del fallo de la MAGOLLA. La examina y dice: HA SI- DO EXPUESTA A UN FUERTE CAMPO MAG- NETICO. INICIO SECUENCIA DE REPA- RACION.\k\r\rLa introduce en su Orificio Multiuso.\k \r\rREPARACION POSITIVA.\r\rY el util�simo ROMI te devuelve la MAGOLLA.
/24 
PERDONE, SE�OR. CONTINUA FUERA DE LIMITES - Dice el ROMI recobrando el RL-C.
/25 
Consiges salir sin que el ROMI no- te que te llevas el RL-B.
/26 
De modo autom�tico la UTV se acti- va transport�ndote hacia la 
/27 
ZONA DE CONTACTO CON EL EXTERIOR. La gravedad disminuye al acercarte al eje de rotaci�n de la base.\k\bHas llegado a la ZOAV.
/28 
periferia de la base. Poco a poco vuelves a ser tan pesado como de costumbre.\k\bHas llegado a la ZOT del Sector 1.
/29 
Una agradable voz sint�tica dice: DEPOSITE LOS OBJETOS VOLUMINOSOS EN LA SALA CONTIGUA Y PROTEJA LOS SENSIBLES ANTES DE PROCEDER A LA DESCOMPRESION... GRACIAS.
/30 
Cierras la UA-E-ZOAV. La ZOCA est� sellada. Se activan automecanismos y, con un silbido en decrecendo, la c�mara se vac�a de aire.
/31 
Al no haber presi�n, revientas y decoras art�sticamente las paredes con tus MUSAVIS.\k\bMUSAVIS = Mucosas y Sanguinolentas Viscosidades.
/32 
La ausencia de aire te pone de un sublime color berenjena.\rAntes de morir, das unas graciosas BOTIPESEC.\k\bBOTIPESEC = Boqueadas Tipo Pez en Seco.
/33 
Al alcanzar el vac�o total, la UA-E-ZOCE se abre.\k\b\rCon paso decidido vas a cruzar ese umbral que te aparta del acogedor Anillo Dorado para enfrentarte a lo desconocido.\k\b\r\rComienza la verdadera misi�n... \k\b\r    FIN DE LA PRIMERA PARTE\r\r    PARA PASAR A LA SEGUNDA\r    UTILIZA LA ORDEN-CLAVE\r    \"
/34 
TAU
/35 
PI
/36 
PSI
/37 
ANTLIAE
/38 
CARINAE
/39 
LIRAE
/40 
En este sitio p�blico, esa acci�n no entra dentro de los esquemas de un COSME que se respete.
/41 
�Sin ninguna Protecci�n d�rmica?
/42 
 �Negativo!
/43 
3: Ang�licus Vol�til. Vibrocantores d�biles e inestables. Emisores en alta frecuencia, receptores en el rango de frecuencias humanas. Muy h�biles con su SUDOR.
/44 
4: Homo Sapiens (Autodenominado). M�s conocido como Cadaver�fagus Erroneoat�micus por su horrible costumbre de sacrificar e ingerir a otros seres de su habitat y el uso antinatural dado a la Energ�a At�mica. D�bil B�pedo Furibundeo y poco fiable. Naturales de Terrea.
/45 
5: Ser de inteligencia Positr�nica de Tecnodia. Aceptados como parte de la Humanidad desde el Per�odo Reivindicativo Asimoviano. Hay di- versos modelos altamente fiables.
/46 
6: Pijus Magn�ficus. Radiante ser oriundo de Berenice. Enormemente inteligente. Superiores en combate y resistente a todo tipo de radia- ciones y toxinas.\rSu primer nombre es verdaderamente descomunal. Altamente recomendable para misiones dif�ciles.
/47 
7: Petrus Ps�quicus. Gravitadores. Expertos en habilidades mentales. Interacci�n ambiental por medios visuales pol�cromos. Muy fiables.
/48 
Seres Positr�nicos sofisticados que tienen a su cargo la Seguridad y el orden del Anillo Dorado.
/49 
Unidad Aislante Estanca entre la ZOAV y ZOCA. Tiene un Optolock.
/50 
Unidad Fija de Almacenamieto Per- sonal. Tiene un LECMA.
/51 
Unidad Protectora Inferior de Tra- bajo.
/52 
Unidad Protectora Inferior de Com- bate.
/53 
Unidad Protectora Media de Combate.
/54 
Unidad Protectora Superior de Com- bate.
/55 
Unidad Protectora Media de Traba- jo. Lleva una holograf�a con tu imagen.
/56 
Unidad Protectora Perif�rica de Manipulaci�n.
/57 
Ante tu evidente falta de control vocal, los presentes te observan irritados.
/58 
Las disertaciones de los GRAMAGA- LES tratan de todos los temas co- nocidos. Cuando a uno se le acaba el rollo, es sustituido por otro de refresco.
/59 
Unidad de Aislamiento Simple de tu ZODE.
/60 
Tarjeta de Identificaci�n Gal�cti- ca. Adaptada molecularmente a tu personalidad.
/61 
Recipiente de L�quidos-Bebible. Ya ha sido usado y est� vac�o.
/62 
Recipiente de L�quidos-Contenedor.
/63 
Unidad Vital Respiratoria. Contie- ne O2.
/64 
Magneto LLave. 
/65 
Porta Documento. Modelo Autodes- trucci�n en Atm�sfera. Cerrado.
/66 
Chip Activador Positr�nico.
/67 
\k\bHas terminado el per�odo de Ins- trucci�n. Ya eres un COSME.
/68 
Nicho Fluorescente para Espec�me- nes. Contenido del No. 
/69 
\r     ACCESO LIBRE A LA ZOED\rNo busques tu dignidad en las es- trellas, sino en el gobierno de tu pensamiento.
/70 
De momento eres un COSME (Comando Saliente en Misi�n Exploratoria) bastante novato, pero no desespe- res, alg�n dia ser�s un CG. Aunque si no te espabilas, puedes acabar siendo un BG.
/71 
Anillo Dorado. Es la base central de entrenamiento para todo tipo de comandos suicidas, aventureros es- paciales y dem�s fauna Gal�ctica. Terminada en Julio de 3.003.
/72 
Bajas la cabeza y tienes a tus plantas uno de los m�s bellos e impresionantes panoramas que contemplarse puedan. La zona por sobre la cual caminas es la parte m�s externa del Anillo Dorado. A trav�s del Mirador Espacial Inferior est�s contemplando el n�cleo de la galaxia, con sus Tres Soles Centrales y las mir�adas de planetas que junto a ellos se agrupan.
/73 
Comando Fracasado Total. Son un triste espect�culo. Les dejan vagar a su antojo, totalmente ignorados, hasta que llega la nave de carga que los devuelve a su lugar de origen.
/74 
Comando en Retorno de Misi�n Ex- ploratoria. Ha hecho algo que t� a�n debes hacer: VOLVER.
/75 
Levantando la cabeza hacia el Mirador Espacial Superior ves dos de los radios que partiendo de la perifer�a del A.D., en la que te encuentras, convergen en el nucleo redondeado central, eje carente de gravedad sobre el cual gira la poderosa estructura y donde est� la ZOCE.
/76 
Cerradura Optica. Reconoce los TIGA.
/77 
\r     Placa Met�lica Mortuoria\r\r   Hemos amado demasiado a las\r estrellas para temer a la noche\r            eterna.\r\r A.R.S. y J.M.M.   RIP - 3.003 dc
/78 
Comandos Muertos en Combate. Vivir�n por siempre en la memoria de sus compa�eros.
/79 
\r        ACCESO A LA ZODO\rRecuerda: Todos los Seres que han existido son descendientes de una forma primordial a la que se di� vida alguna vez...
/80 
Holograma con efecto Zoom Visualmente Activado. En el se aprecia la galaxia en 3D y girando graciosamente. Lo asombroso es que al fijar en cualquier punto tu mirada activas un Zoom que conduce tu vista cada vez m�s profundamente dentro de la zona elegida, se�alando primero regiones enteras, luego sistemas, planetas, etc., destacando siempre los tipos de razas dominantes.
/81 
Unidad de Transporte Vertical ZOT-ZOAV.
/82 
\r        ACCESO A ZOCE\r   SOLO PERSONAL AUTORIZADO
/83 
Capit�n Gal�ctico.
/84 
Barrendero Gal�ctico.
/85 
Gran Maestro Gal�ctico. Uno de los Sabios que instruyen continuamente al personal del Anillo Dorado pre- par�ndolo para todo tipo de misio- nes.
/86 
Comando en Reposo en el Anillo Do- rado.\rD�cese del personal al que todav�a no se ha asignado misi�n por estar en per�odo de instrucci�n.
/87 
Robot de Mantenimiento e Informa- ci�n. Producido en Tecnodia.
/88 
Part�culas Euforizantes de Acci�n Selectiva. Sustancias vol�tiles que producen sensaci�n de bienes- tar y euforia en las cansadas tro- pas. Al ser selectivas molecular- mente, las pulverizadas hoy no te afectan.
/89 
1: Saurius Pedorrus. Interacci�n ambiental por medios odor�feros, predominando el H2S. Muy fuertes y sabios.
/90 
2: Eridanus Cian�ticus. Peque�o remolino de niebla azulplata de pura energ�a. Interacci�n ambiental por medio de pseud�podos intangibles de emociones primarias. Naturales de Gamma Eridanii. Muy inestables.
/91 
Urna de Sue�o. No puedes abrirla porque eres un COSME en activo con el permiso on�rico cancelado.
/92 
Lector magn�tico de la UFAP.
/93 
Unidad de Transporte Vertical ZOAV-ZOT.
/94 
\r              ZOCA\r\r    SOLO PERSONAL AUTORIZADO\r\r            PRECAUCION\r\r REVISE SU EQUIPO ANTES DE ENTRAR
/95 
Unidad de Aislamiento Estanca  ZOCA-ZOCE. Para abrirse requiere que haya vac�o a ambos lados.
/96 
\r       ZOCE : ACCESO FINAL\r\r         PELIGRO: VACIO
;------------------------------------------------------------------------------
/OTX    ;Object Texts
/0 

/1 
una UFAP
/2 
unas UPI-T
/3 
unas UPI-CO
/4 
una UPM-CO
/5 
una UPS-CO
/6 
una UPM-T
/7 
unas UPP-M
/8 

/9 

/10 

/11 
una TIGA
/12 
un RL-B
/13 
un RL-C
/14 
una UVIR
/15 
una MAGOLLA
/16 
un PD-AA
/17 
un CHAPO
;------------------------------------------------------------------------------
/LTX    ;Location Texts
/0 
\r\r                     ESPACIAL\r\r              (La CONGA vs el CELO)\r\r\r        PRIMERA PARTE : EN EL ANILLO DORADO\r\r                     Direcci�n\r                  Andr�s  Samudio\r\r               Programaci�n y sonido\r                Juan Manuel Medina\r\r                     Gr�ficos\r                  Carlos Marqu�s\r                Juan Antonio Darder\r\r             (C) AVENTURAS A.D. -1990-\r
/1 
La maravillosa Supercomando Zyanya de Cozumel se acerca con su famoso contoneo er�tico-militar.\k Te mira como a un insecto, tu te derrites en desorbitado babeo mientras ella se aleja vibrante
/2 
Un ej�rcit de ROMA aparece y lo dejan todo, t� incluido, lavado, engrasado, pulido y abrillantado.\k Luego, los Robots de Mantenimiento se dirigen con presteza a otra secci�n
/3 
S�lo los refuerzos estructurales de �ngulo maleable rompen la mono- ton�a de �stos pasillos de circun- valaci�n
/4 
Toda la estructura vibra al trans- mitir la enorme potencia generada por el despegue de un gran KRUGUER\k\bKRUGUER = Crucer de Guerra
/5 
Dicen que por �stos pasillos a�n vagan los alucinados fantasmas de algunos miembros del equip de A.D
/6 
Antes no lo hab�a notado pero... �Menudo pie me lleva por el pasi- llo que se estremece al ritm de mis caderas! Es fant�stico
/7 
Las luces de atenci�n parpadean y se oye el penetrante gemido que anuncia la llegada de un VEECO.\k\bVEECO =  Veh�culo Espacial de Ex- ploraci�n y Combate
/8 
Como una exhalaci�n pasa Jabato huyendo del hacha lanzada por el enano Maluva.\k Mientras el arma rebota aparatosamente contra los paneles, ambos  te miran avergonzados y se escurren furtivamente
/9 
Mientras deambulas por estos solitarios pasillos, diversas emociones te embargan: el amargo recuerd de tu dura preparaci�n, tus valientes ansias de aventura y el temor ante los desconocidos peligros de tu misi�n
/10 
         Sector 4 - ZOT\rFrente a una entrada con un INVI superior
/11 
         Sector 3 - ZOT\rEsta Zona de Tr�nsito es una de las m�s concurridas, por ello tiene en el suelo un amplio MIESINF. En una de las paredes est�n grabadas las letras A.D
/12 
         Sector 3 - ZOT\rTe encuentras frente a la entrada de la ZOES, desde dentro llegan fuertes risas de CORME y, si est�s de mala suerte, puedes ver salir alg�n ebrio COFRATO en su ronda final antes de abandonar la base
/13 
         Sector 2 - ZOT\rFrente a una UA-S con OPTOLOCK. En el bajo techo hay un MIESUP
/14 
         Sector 2 - ZOT\rEn �sta solitaria Zona de Tr�nsito hay una peque�a PMM, quiz� �nico recuerd de algunos valientes COMUCOS
/15 
         Sector 1 - ZOT\rFrente a una amplia entrada con un elegante INVI a un lado y un moderno HOZOOVIAC del otro
/16 
         Sector 1 - ZOT\rFrente a la UTV con un INVI supe- rior. Por �stos pasillos del Pri- mer Sector suelen patrullar algu- nos BLOQUEATORS e INTERCEPTORS
/17 
         Sector 4 - ZOT              Pasas frente a varias dependencias exclusivas para los CG. De momento te est�n vedadas hasta que tengas el rango suficiente
/18 
         Sector 4 - ZOED                    En la Zona Educacional toda la atenci�n est� centrada alrededor del sabio GRAMAGAL, quien, frente al Monitor del Espacio Profundo, instruye a los diversos CORREADS
/19 
         Sector 4 - ZOES\rLas vaporizaciones de PEAS produ- cen una densa atm�sfera y hacen que la Zona de Esparcimiento est� casi siempre en penumbra. Algunos CORME, de otra unidad, celebran su vuelta mientras un ocupado ROMI mantiene el orden
/20 
         Sector 1 - ZODO\rEn la suave penumbra que reina en la Zona de Documentaci�n destacan varios NIFLORES bien iluminados. Ellos albergan todo el conocimien- to sobre las muchas otras razas de la CONGA
/21 
         Sector 2 - ZODE              Aunque sobrias, las Zonas de Des- canso son muy acogedoras, con c�- modos muebles y la imprescindible URSU
/22 
         Sector 0 - ZOAV\rEn la Zona de Almacenamiento y de Vestuario hay que prepararse para afrontar los rigores del espacio exterior. Hay varias estanter�as con equipo. En un extremo hay una UA-E con un un llamativo INVI
/23 
         Sector 0 - ZOCA              La Zona de Cambio Atmosf�rico tie- ne gruesas y acolchadas paredes. Hay una UA-E y una UA-V con un INVI superior
;------------------------------------------------------------------------------
/CON    ;Conections
/0
/1
/2
/3
/4
/5
/6
/7
/8
/9
/10
GIRO  17
ANTIG 11
ENTRA 18
/11
GIRO  10
ANTIG 12
/12
GIRO  11
ANTIG 13
ENTRA 19
/13
GIRO  12
ANTIG 14
ENTRA 21
/14
GIRO  13
ANTIG 15
/15
GIRO  14
ANTIG 16
ENTRA 20
/16
GIRO  15
ANTIG 17
SUBIR 22
/17
GIRO  16
ANTIG 10
/18
SALIR 10
/19
SALIR 12
/20
SALIR 15
/21
SALIR 13
/22
BAJAR 16
ENTRA 23
/23
SALIR 22
;------------------------------------------------------------------------------
/OBJ    ;Objects data
;obj.no  starts.at   weight    c w  5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0    noun    adjective
/0        NOT_CREATED  1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    COMPU   _ 
/1        21           0       Y _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    ARMAR   _ 
/2        WORN         20      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    ZAPAT   _ 
/3        22           30      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    BOTAS   _ 
/4        22           48      Y Y  _ _ _ _ _ _ _ _ _ _ _ Y _ _ _ Y    TRAJE   _ 
/5        22           22      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    CASCO   _ 
/6        WORN         40      Y Y  _ _ _ _ _ _ _ _ _ _ _ Y _ _ _ Y    MONO    _ 
/7        4            6       _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    GUANT   _ 
/8        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    OB8     _ 
/9        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    OB9     _ 
/10       NOT_CREATED  1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    PUERT   _ 
/11       NOT_CREATED  2       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    TARJE   _ 
/12       19           9       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    COPA    _ 
/13       19           10      _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y _ _ _    BOTEL   _ 
/14       22           12      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ Y _ _ _    BURBU   _ 
/15       4            1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    LLAVE   _ 
/16       1            3       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y _ Y _    SOBRE   _ 
/17       4            3       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    CHIP    _ 
;------------------------------------------------------------------------------
/PRO 0

_       _               DESTROY 0 
                        DESTROY 10 
                        AT      0 
                        PROCESS 6 
                        ABILITY 8 200 
                        SET     125 
                        DESC    0 
                        ANYKEY  
                        CLS     
                        GOTO    18 
                        NOTEQ   60 105 
                        GFX     0 1 
                        GFX     0 4 
                        WINDOW  3 
                        PICTURE 18 
                        DISPLAY 0 
                        WINAT   14 1 
                        WINSIZE 1 51 
                        PICTURE 1 
                        DISPLAY 0 
                        WINAT   24 16 
                        WINSIZE 1 35 
                        DISPLAY 0 
                        WINAT   23 2 
                        WINSIZE 1 13 
                        PICTURE 8 
                        DISPLAY 0 
                        WINAT   15 0 
                        WINSIZE 8 1 
                        PICTURE 0 
                        DISPLAY 0 
                        WINAT   15 15 
                        WINSIZE 9 1 
                        DISPLAY 0 
                        WINAT   15 52 
                        DISPLAY 0 
                        WINAT   14 0 
                        WINSIZE 1 1 
                        PICTURE 2 
                        DISPLAY 0 
                        WINAT   14 15 
                        PICTURE 7 
                        DISPLAY 0 
                        WINAT   23 15 
                        PICTURE 6 
                        DISPLAY 0 
                        WINAT   14 52 
                        PICTURE 4 
                        DISPLAY 0 
                        WINAT   23 0 
                        PICTURE 3 
                        DISPLAY 0 
                        WINAT   24 15 
                        DISPLAY 0 
                        WINAT   24 52 
                        PICTURE 5 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 
                        WINDOW  2 
                        CLS     
                        RESTART 

_       _               CLEAR   28 
                        NOTZERO 0 
                        SET     28 

_       _               NOTEQ   60 105 
                        WINDOW  0 
                        WINAT   0 0 
                        WINSIZE 14 99 
                        NOTEQ   60 105 
                        NOTEQ   33 1 
                        NOTEQ   33 2 
                        PICTURE [38] 
                        GFX     0 1 
                        GFX     0 4 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 

_       _               WINDOW  1 
                        WINAT   15 17 
                        WINSIZE 9 34 
                        CLS     
                        ZERO    28 
                        DESC    [38] 
                        SYSMESS 20 
                        PROCESS 3 

_       _               PROCESS 1 

;------------------------------------------------------------------------------
/PRO 1

_       _               PROCESS 2 
                        NOTZERO 84 
                        SKIP    2 

_       _               EQ      31 255 
                        PLUS    32 1 
                        CLEAR   31 
                        SKIP    1 

_       _               PLUS    31 1 

_       _               CLEAR   84 
                        PROCESS 4 
                        PROCESS 19 
                        CARRIED 17 
                        NOTWORN 7 
                        ZERO    144 
                        SET     144 
                        MESSAGE 16 

_       _               REDO    

;------------------------------------------------------------------------------
/PRO 2

_       _               DESTROY 0 
                        DESTROY 10 

_       _               AT      19 
                        NOTEQ   33 56 
                        MINUS   148 1 
                        ZERO    148 
                        MESSAGE 22 
                        ANYKEY  
                        CLS     
                        SYNONYM SALIR _ 
                        SET     89 
                        PROCESS 21 

_       _               AT      19 
                        NOTEQ   33 56 
                        CHANCE  50 
                        MESSAGE 19 

_       _               ATGT    9 
                        ATLT    18 
                        CHANCE  30 
                        LET     2 8 
                        PROCESS 18 
                        PLUS    149 1 
                        NEWLINE 
                        DESC    [149] 
                        SYSMESS 20 

;------------------------------------------------------------------------------
/PRO 3

_       _               ZERO    146 
                        SET     146 
                        MESSAGE 67 

_       _               LISTOBJ 

_       _               NOTAT   13 
                        NOTAT   21 
                        CLEAR   141 

_       _               AT      19 
                        ZERO    148 
                        LET     148 5 

_       _               AT      16 
                        CHANCE  35 
                        ZERO    143 
                        NEWLINE 
                        MESSAGE 18 
                        SET     143 

;------------------------------------------------------------------------------
/PRO 4

_       _               LET     134 51 
                        LET     135 70 
                        LET     3 79 
                        LET     117 1 
                        CLEAR   106 
                        PROCESS 8 
                        SYSMESS 2 

_       _               PROCESS 13 
                        COPYFF  109 33 
                        GT      33 66 
                        SET     84 

;------------------------------------------------------------------------------
/PRO 5

_       _               CLEAR   128 
                        CLEAR   129 
                        ZERO    104 
                        LET     2 150 

_       _               COPYOF  [128] 3 
                        EQ      3 255 
                        SKIP    4 

_       _               SETCO   [128] 
                        NOTEQ   125 255 
                        HASNAT  [125] 
                        SKIP    2 

_       _               SAME    3 120 
                        PROCESS 7 
                        SKIP    1 

_       _               EQ      120 249 
                        PRESENT [128] 
                        PROCESS 7 

_       _               PLUS    128 1 
                        SKIP    251 

_       _               SET     125 
                        ZERO    129 
                        ZERO    104 
                        PROCESS 11 
                        CLEAR   127 
                        NOTDONE 

_       _               NOTZERO 127 
                        GT      129 1 
                        LET     [2] 100 
                        PLUS    2 1 
                        SET     [2] 
                        PLUS    2 1 
                        PLUS    129 1 

_       _               SET     [2] 
                        ADD     129 104 
                        LET     117 1 
                        SET     106 
                        CLEAR   127 
                        PROCESS 13 
                        CLEAR   104 
                        SET     35 
                        LT      109 18 
                        SYNONYM _ COMPU 
                        ADD     109 34 
                        SETCO   [109] 
                        DONE    

_       _               EQ      109 255 
                        SYNONYM _ TODO  

;------------------------------------------------------------------------------
/PRO 6

_       _               HASNAT  247 
                        SYSMESS 0 
                        ANYKEY  
                        EXIT    0 

_       _               LET     254 254 
                        SFX     0 254 
                        NOTZERO 255 
                        LET     254 253 
                        CLEAR   255 

_       _               NOTEQ   255 29 
                        CLEAR   [255] 

_       _               PLUS    255 1 
                        SMALLER 255 254 
                        SKIP    254 

_       _               LET     53 64 
                        LET     42 2 
                        RESET   
                        WINDOW  2 
                        WINAT   15 2 
                        WINSIZE 8 12 
                        MODE    2 
                        PAPER   1 
                        WINDOW  7 
                        WINAT   0 0 
                        WINSIZE 100 100 
                        CLS     

;------------------------------------------------------------------------------
/PRO 7

_       _               LET     103 108 
                        ADD     128 103 
                        COPYBF  [2] 103 
                        PLUS    2 1 
                        COPYBF  [2] 128 
                        PLUS    2 1 
                        PLUS    129 1 

;------------------------------------------------------------------------------
/PRO 8

_       _               LET     2 150 
                        CLEAR   104 

_       _               COPYBF  [2] 3 
                        PLUS    2 1 
                        PLUS    3 1 
                        COPYBF  [2] 134 
                        PLUS    2 1 
                        PLUS    104 1 
                        BIGGER  135 134 
                        PLUS    134 1 
                        SKIP    255 

_       _               SET     [2] 

;------------------------------------------------------------------------------
/PRO 9

_       _               LT      110 10 

_       _               PRINT   110 

;------------------------------------------------------------------------------
/PRO 10

_       _               WINDOW  3 
                        WINAT   [117] 2 
                        WINSIZE 1 12 
                        PAPER   1 
                        INK     0 
                        NOTZERO 113 
                        PAPER   6 
                        INK     0 

_       _               CLS     
                        COPYFF  117 2 
                        MINUS   2 15 
                        COPYFF  2 110 
                        PLUS    110 1 
                        PROCESS 9 
                        SPACE   
                        ADD     2 2 
                        ADD     111 2 
                        COPYFF  [2] 3 

_       _               SYSMESS [3] 
                        SAVEAT  

;------------------------------------------------------------------------------
/PRO 11

_       _               WINDOW  2 
                        PRINTAT 7 0 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        WINDOW  1 
                        DONE    

;------------------------------------------------------------------------------
/PRO 12

_       _               WINDOW  3 
                        PLUS    105 1 
                        WINAT   23 2 
                        WINSIZE 1 13 
                        PICTURE 8 
                        EQ      103 99 
                        PICTURE 9 
                        MINUS   105 1 

_       _               DISPLAY 0 
                        EQ      103 99 
                        PLUS    112 1 
                        WINDOW  1 
                        DONE    

_       _               WINAT   [105] 2 
                        WINSIZE 1 12 
                        PAPER   1 
                        INK     0 
                        CLS     
                        PLUS    110 1 
                        PROCESS 9 
                        SPACE   
                        SYSMESS [103] 
                        SAVEAT  

_       _               PLUS    112 1 
                        PLUS    103 1 
                        WINDOW  1 
                        EQ      33 58 
                        PLUS    103 1 

;------------------------------------------------------------------------------
/PRO 13

_       _               LET     108 150 
                        COPYFF  104 107 
                        ZERO    106 
                        WINDOW  1 

_       _               CLEAR   112 
                        LET     105 14 
                        COPYFF  108 111 
                        CLEAR   110 
                        GT      104 8 
                        LET     107 8 

_       _               LT      [108] 255 
                        COPYFF  [108] 103 
                        PLUS    108 2 
                        PROCESS 12 
                        MINUS   107 1 
                        NOTZERO 107 
                        SKIP    255 

_       _               GT      104 8 
                        LET     103 99 
                        PROCESS 12 

_       _               PROCESS 14 
                        SAME    109 112 
                        PROCESS 11 
                        GT      104 8 
                        SKIP    1 

_       _               ADD     109 109 
                        ADD     111 109 
                        MINUS   109 1 
                        COPYFF  [109] 109 
                        WINDOW  1 
                        PROCESS 11 
                        DONE    

_       _               PROCESS 11 
                        LET     117 1 
                        NOTEQ   [108] 255 
                        SKIP    250 

_       _               REDO    

;------------------------------------------------------------------------------
/PRO 14

_       _               PLUS    117 14 

_       _               SET     113 
                        PROCESS 10 

_       _               PROCESS 15 
                        ISNDONE 
                        SKIP    255 

_       _               CLEAR   113 
                        PROCESS 10 
                        WINDOW  1 

_       _               EQ      60 113 
                        GT      117 15 
                        MINUS   117 1 
                        SKIP    252 

_       _               EQ      60 113 
                        COPYFF  105 117 
                        SKIP    251 

_       _               EQ      60 97 
                        SMALLER 117 105 
                        PLUS    117 1 
                        SKIP    250 

_       _               EQ      60 97 
                        LET     117 15 
                        SKIP    249 

_       _               EQ      60 13 
                        MINUS   117 14 
                        COPYFF  117 109 
                        SKIP    7 

_       _               ZERO    116 
                        EQ      60 105 
                        PROCESS 11 
                        SET     84 
                        RESTART 

_       _               EQ      60 112 
                        GT      104 8 
                        COPYFF  112 109 
                        SKIP    6 

_       _               GT      60 47 
                        LT      60 58 
                        COPYFF  60 61 
                        CLEAR   60 
                        PLUS    61 10 
                        EQ      61 58 
                        LET     61 68 

_       _               NOTZERO 60 
                        SKIP    244 

_       _               LT      61 59 
                        SKIP    243 

_       _               GT      61 68 
                        SKIP    242 

_       _               COPYFF  61 109 
                        MINUS   109 58 

_       _               BIGGER  109 112 
                        SKIP    240 

_       _               COPYFF  109 117 
                        PLUS    117 14 
                        SET     113 
                        EXTERN  0 0 

_       _               SAME    109 112 
                        GT      104 8 
                        DONE    

_       _               PROCESS 10 
                        CLEAR   118 
                        CLEAR   113 
                        PROCESS 10 
                        CLEAR   116 
                        WINDOW  1 
                        ZERO    106 
                        SYSMESS [3] 
                        SPACE   

SACAR   _               SET     118 

METER   _               SET     118 

_       _               NOTZERO 106 
                        SYSMESS [3] 
                        NOTZERO 118 
                        CLEAR   118 
                        SPACE   
                        DONE    

_       _               NOTZERO 106 
                        NEWLINE 

;------------------------------------------------------------------------------
/PRO 15

_       _               INKEY   
                        SKIP    1 

_       _               NOTDONE 

_       _               BORDER  0 
                        EQ      60 13 
                        CLEAR   60 
                        DONE    

_       _               EQ      60 13 
                        LET     60 13 
                        DONE    

_       _               EQ      60 27 
                        LET     60 105 
                        DONE    

_       _               NOTZERO 60 
                        SKIP    4 

_       _               EQ      61 72 
                        LET     60 113 
                        DONE    

_       _               EQ      61 80 
                        LET     60 97 
                        DONE    

_       _               EQ      61 77 
                        LET     60 112 
                        DONE    

_       _               EQ      61 75 
                        LET     60 111 
                        DONE    

_       _               EQ      60 81 
                        LET     60 113 
                        DONE    

_       _               EQ      60 65 
                        LET     60 97 
                        DONE    

_       _               EQ      60 73 
                        LET     60 105 
                        DONE    

_       _               EQ      60 79 
                        LET     60 111 
                        DONE    

_       _               EQ      60 80 
                        LET     60 112 

_       _               EQ      60 109 
                        LET     60 13 

_       _               EQ      60 77 
                        LET     60 13 

_       _               EQ      60 32 
                        LET     60 13 

;------------------------------------------------------------------------------
/PRO 16

_       _               CLEAR   126 
                        DOALL   [120] 
                        WHATO   
                        NOTEQ   125 255 
                        HASNAT  125 
                        DONE    

_       _               PLUS    126 1 

;------------------------------------------------------------------------------
/PRO 17

_       _               SYSMESS 17 
                        DPRINT  31 
                        SYSMESS 20 
                        ANYKEY  
                        CLS     

_       _               SYSMESS 2 
                        LET     3 102 
                        CLEAR   134 
                        LET     135 1 
                        CLEAR   106 
                        PROCESS 8 
                        LET     117 1 
                        NOTZERO 253 
                        LET     [2] 107 
                        PLUS    2 1 
                        LET     [2] 2 
                        PLUS    2 1 
                        PLUS    104 1 
                        SET     [2] 

_       _               SET     116 
                        PROCESS 13 
                        EQ      109 1 
                        NEWLINE 
                        QUIT    
                        EXIT    0 

_       _               EQ      109 2 
                        RAMLOAD 252 
                        RESTART 

_       _               GOTO    0 
                        RESTART 

;------------------------------------------------------------------------------
/PRO 18

_       _               RANDOM  149 
                        MINUS   149 1 

_       _               BIGGER  149 2 
                        SUB     2 149 
                        SKIP    255 

;------------------------------------------------------------------------------
/PRO 19

_       _               LET     117 1 
                        CLEAR   104 

COGER   _               COPYFF  38 120 
                        SET     127 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 52 
                        DONE    

COGER   TODO            DOALL   255 

COGER   _               HASAT   2 
                        SYSMESS 8 
                        SYSMESS 66 
                        DONE    

COGER   BOTAS           ZERO    88 
                        SYSMESS 8 
                        SYSMESS 66 
                        DONE    

COGER   _               AUTOG   
                        DONE    

DEJAR   _               LET     120 254 
                        SET     127 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 53 
                        DONE    

DEJAR   TODO            DOALL   254 

DEJAR   _               AUTOD   
                        DONE    

PONER   _               LET     120 254 
                        SET     127 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 28 
                        DONE    

PONER   TODO            DOALL   254 

PONER   BOTAS           WORN    2 
                        SYSMESS 19 
                        DONE    

PONER   ZAPAT           WORN    3 
                        SYSMESS 19 
                        DONE    

PONER   TRAJE           NOTWORN 6 
                        NOTWORN 3 
                        NOTWORN 2 
                        SKIP    3 

PONER   TRAJE           SYSMESS 19 
                        DONE    

PONER   MONO            NOTWORN 4 
                        NOTWORN 3 
                        NOTWORN 2 
                        SKIP    1 

PONER   MONO            SYSMESS 19 
                        DONE    

PONER   _               AUTOW   
                        DONE    

QUITA   _               LET     120 253 
                        SET     127 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 29 
                        DONE    

QUITA   TODO            DOALL   253 

QUITA   MONO            NOTAT   21 
                        ATLT    22 
                        MES     40 
                        MESSAGE 42 
                        DONE    

QUITA   MONO            WORN    3 
                        SYSMESS 19 
                        DONE    

QUITA   MONO            WORN    2 
                        SYSMESS 19 
                        DONE    

QUITA   TRAJE           NOTAT   21 
                        ATLT    22 
                        MES     40 
                        MESSAGE 42 
                        DONE    

QUITA   TRAJE           WORN    3 
                        SYSMESS 19 
                        DONE    

QUITA   TRAJE           WORN    2 
                        SYSMESS 19 
                        DONE    

QUITA   _               AUTOR   
                        DONE    

SACAR   _               LET     120 249 
                        LET     125 31 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 64 
                        DONE    

SACAR   _               COPYFF  51 132 
                        COPYFF  51 120 
                        EQ      51 1 
                        ZERO    139 
                        NEWLINE 
                        SYSMESS 63 
                        DONE    

SACAR   _               PROCESS 16 
                        NOTZERO 126 
                        SET     127 
                        PROCESS 5 
                        NEWLINE 

SACAR   _               ZERO    126 
                        SYSMESS 55 
                        SYSMESS 45 
                        DONE    

SACAR   TODO            DOALL   [132] 

SACAR   _               AUTOT   [132] 
                        DONE    

USAR    _               LET     120 254 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 70 
                        DONE    

USAR    LLAVE           AT      22 
                        SET     147 
                        ZERO    88 
                        ZERO    87 
                        MESSAGE 11 
                        DONE    

USAR    LLAVE           AT      22 
                        ZERO    88 
                        SET     88 
                        CLEAR   87 
                        MESSAGE 7 
                        DONE    

USAR    TARJE           ATGT    21 
                        NOTZERO 140 
                        SYNONYM CERRA COMPU 
                        SKIP    31 

USAR    TARJE           ATGT    21 
                        SYNONYM ABRIR COMPU 
                        SKIP    16 

USAR    TARJE           AT      13 
                        NOTZERO 141 
                        SYNONYM CERRA PUERT 
                        SKIP    29 

USAR    TARJE           AT      13 
                        SYNONYM ABRIR PUERT 
                        SKIP    14 

USAR    LLAVE           AT      21 
                        SYNONYM ABRIR ARMAR 
                        SKIP    13 

USAR    _               SYSMESS 18 
                        DONE    

METER   _               LET     120 249 
                        LET     125 31 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 5 
                        DONE    

METER   ARMAR           ZERO    139 
                        NEWLINE 
                        SYSMESS 63 
                        DONE    

METER   _               CLEAR   133 
                        HASAT   0 
                        SET     133 

METER   _               COPYFF  51 132 
                        LET     120 254 
                        PROCESS 16 
                        NOTZERO 126 
                        SET     127 
                        PROCESS 5 
                        NEWLINE 

METER   _               ZERO    126 
                        NEWLINE 
                        SYSMESS 65 
                        DONE    

METER   TODO            DOALL   254 

METER   _               HASNAT  1 
                        NOTZERO 133 
                        SYSMESS 72 
                        SETCO   [132] 
                        SYSMESS 73 
                        DONE    

METER   _               SAME    51 132 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

METER   _               AUTOP   [132] 
                        DONE    

ABRIR   _               LET     120 249 
                        LET     125 3 
                        AT      22 
                        CREATE  0 

ABRIR   _               AT      13 
                        CREATE  10 

ABRIR   _               PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 8 
                        SYSMESS 34 
                        DONE    

ABRIR   COMPU           NOTCARR 11 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

ABRIR   COMPU           ZERO    140 
                        SET     140 
                        MESSAGE 5 
                        PICTURE 25 
                        SFX     0 255 
                        DONE    

ABRIR   PUERT           NOTCARR 11 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

ABRIR   PUERT           ZERO    141 
                        SET     141 
                        MESSAGE 5 
                        PICTURE 25 
                        SFX     0 255 
                        DONE    

ABRIR   ARMAR           ZERO    139 
                        CARRIED 15 
                        SET     147 
                        MES     3 
                        NOTZERO 87 
                        SET     139 
                        SYSMESS 35 
                        MESSAGE 6 
                        DESTROY 15 
                        DONE    

ABRIR   ARMAR           ZERO    139 
                        CARRIED 15 
                        MESSAGE 4 
                        DONE    

ABRIR   ARMAR           ZERO    139 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

ABRIR   BURBU           PICTURE 26 
                        SFX     0 255 
                        MESSAGE 1 
                        SYSMESS 75 
                        PROCESS 17 

ABRIR   SOBRE           DESTROY 16 
                        MESSAGE 17 
                        DONE    

ABRIR   BOTEL           MESSAGE 2 
                        DONE    

ABRIR   _               SYSMESS 62 
                        DONE    

CERRA   _               LET     120 249 
                        LET     125 3 
                        ATGT    21 
                        CREATE  0 

CERRA   _               AT      13 
                        CREATE  10 

CERRA   _               PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 8 
                        SYSMESS 67 
                        DONE    

CERRA   ARMAR           NOTZERO 139 
                        CLEAR   139 
                        SYSMESS 63 
                        DONE    

CERRA   COMPU           NOTCARR 11 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

CERRA   COMPU           AT      22 
                        NOTZERO 140 
                        CLEAR   140 
                        SYSMESS 15 
                        PICTURE 25 
                        SFX     0 255 
                        DONE    

CERRA   COMPU           NOTCARR 6 
                        ISNOTAT 6 23 
                        ABSENT  12 
                        ABSENT  15 
                        ABSENT  16 
                        ABSENT  17 
                        PROCESS 23 

CERRA   COMPU           MESSAGE 29 
                        DONE    

CERRA   PUERT           NOTZERO 141 
                        CLEAR   141 
                        SYSMESS 15 
                        PICTURE 25 
                        SFX     0 255 
                        DONE    

CERRA   _               SYSMESS 62 
                        DONE    

EXAMI   _               PROCESS 20 
                        DONE    

ALMAC   _               LET     134 50 
                        LET     135 52 
                        LET     3 104 
                        NOTZERO 253 
                        LET     135 53 

ALMAC   _               SET     106 
                        PROCESS 8 
                        LET     117 2 
                        LET     117 2 
                        PROCESS 13 
                        COPYFF  109 34 

ALMAC   RAMSA           RAMSAVE 
                        SET     253 
                        SYSMESS 15 
                        ANYKEY  
                        LET     60 105 
                        RESTART 

ALMAC   SAVED           SAVE    2 
                        LET     60 105 
                        RESTART 

ALMAC   LOADD           ZERO    253 
                        LOAD    2 
                        CLEAR   253 

ALMAC   LOADD           NOTZERO 253 
                        LOAD    2 
                        SET     253 

ALMAC   RAMLO           RAMLOAD 252 

ALMAC   _               RESTART 

SALID   _               PROCESS 21 
                        DONE    

FIN     _               LET     3 101 
                        CLEAR   134 
                        LET     135 2 
                        SET     106 
                        PROCESS 8 
                        LET     117 1 
                        PROCESS 13 
                        EQ      109 1 
                        GOTO    0 
                        RESTART 

FIN     _               NOTZERO 109 
                        QUIT    
                        EXIT    0 

FIN     _               LET     60 105 
                        RESTART 

JUGAD   _               SYSMESS 17 
                        DPRINT  31 
                        SYSMESS 20 
                        DONE    

_       _               CLEAR   106 
                        PROCESS 11 
                        NEWLINE 

INVEN   _               PROCESS 11 
                        ZERO    1 
                        NOTWORN 7 
                        NOTWORN 6 
                        NOTWORN 4 
                        NOTWORN 5 
                        NOTWORN 14 
                        NOTWORN 3 
                        NOTWORN 2 
                        SYSMESS 10 
                        DONE    

INVEN   _               NOTZERO 1 
                        SYSMESS 9 
                        LISTAT  254 

INVEN   _               NOTWORN 7 
                        NOTWORN 6 
                        NOTWORN 4 
                        NOTWORN 7 
                        NOTWORN 5 
                        NOTWORN 14 
                        NOTWORN 3 
                        NOTWORN 2 
                        DONE    

INVEN   _               SYSMESS 11 
                        LISTAT  253 
                        DONE    

MIRAR   _               LET     60 105 
                        RESTART 

LEGIO   _               MESSAGE 0 
                        DONE    

ESPER   _               SYSMESS 6 
                        DONE    

ESCUC   _               AT      18 
                        MESSAGE 58 
                        DONE    

ESCUC   _               AT      21 
                        SYSMESS 99 
                        DONE    

ESCUC   _               SYSMESS 68 
                        DONE    

HABLA   _               AT      19 
                        ZERO    145 
                        SET     145 
                        MESSAGE 20 
                        DONE    

HABLA   _               AT      19 
                        NOTZERO 145 
                        ISAT    11 252 
                        MESSAGE 21 
                        PLACE   11 254 
                        DONE    

HABLA   _               AT      19 
                        NOTZERO 147 
                        PRESENT 15 
                        ZERO    87 
                        MESSAGE 23 
                        SET     87 
                        DONE    

HABLA   _               AT      19 
                        MESSAGE 19 
                        DONE    

HABLA   _               AT      16 
                        MESSAGE 15 
                        DONE    

HABLA   _               AT      18 
                        MESSAGE 57 
                        DONE    

HABLA   _               SYSMESS 69 
                        DONE    

_       _               SYSMESS 8 
                        SYSMESS 54 

;------------------------------------------------------------------------------
/PRO 20

_       _               LET     2 150 
                        COPYFF  38 134 
                        ADD     134 134 
                        COPYFF  134 135 
                        PLUS    134 112 
                        PLUS    135 49 

_       _               COPYBF  [2] 134 
                        PLUS    2 1 
                        COPYBF  [2] 135 
                        PLUS    2 1 
                        PLUS    134 1 
                        PLUS    135 1 
                        LT      2 154 
                        SKIP    255 

_       _               LET     104 8 
                        LET     134 160 
                        LET     135 43 
                        NOTAT   20 
                        LET     104 2 
                        SKIP    1 

_       _               COPYBF  [2] 134 
                        PLUS    2 1 
                        COPYBF  [2] 135 
                        PLUS    2 1 
                        PLUS    134 1 
                        PLUS    135 1 
                        LT      134 165 
                        SKIP    255 

_       _               AT      16 
                        LET     [2] 165 
                        PLUS    2 1 
                        LET     [2] 48 
                        PLUS    2 1 
                        PLUS    104 1 

_       _               AT      13 
                        CREATE  10 

_       _               ATGT    21 
                        CREATE  0 

_       _               SET     [2] 
                        LET     120 249 
                        PROCESS 5 
                        DESTROY 0 
                        DESTROY 10 
                        GT      109 17 
                        AT      20 
                        MES     68 

_       _               GT      109 17 
                        MESSAGE [109] 
                        DONE    

_       _               COPYFF  109 134 
                        PLUS    134 49 
                        MESSAGE [134] 
                        WHATO   
                        SET     136 
                        LET     137 50 
                        HASNAT  4 
                        LET     137 49 

_       LLAVE           SET     147 
                        MES     8 
                        ZERO    87 
                        MESSAGE 9 

_       LLAVE           NOTZERO 87 
                        MESSAGE 10 

_       BOTAS           ZERO    88 
                        MESSAGE 12 

_       ARMAR           ZERO    139 
                        SYSMESS 63 
                        CLEAR   136 

_       ARMAR           NOTZERO 139 
                        SYSMESS 35 

_       COMPU           ZERO    140 
                        SYSMESS 13 
                        CLEAR   136 

_       COMPU           NOTZERO 140 
                        SYSMESS 71 

_       PUERT           ZERO    141 
                        SYSMESS 13 

_       PUERT           NOTZERO 141 
                        SYSMESS 71 

_       _               NOTWORN [51] 
                        HASAT   23 
                        SYSMESS 23 

_       _               HASAT   31 
                        NOTZERO 136 
                        COPYFF  51 120 
                        PROCESS 16 
                        NOTZERO 126 
                        SYSMESS [137] 
                        LISTAT  [120] 

;------------------------------------------------------------------------------
/PRO 21

_       _               NOTZERO 89 
                        CLEAR   89 
                        SKIP    8 

_       _               LET     33 1 
                        LET     3 0 
                        LET     2 150 

_       _               COPYFF  38 122 
                        PROCESS 22 
                        ISNDONE 
                        MOVE    122 
                        LET     103 125 
                        ADD     33 103 
                        COPYBF  [2] 103 
                        PLUS    2 1 
                        COPYBF  [2] 33 
                        PLUS    2 1 
                        PLUS    3 1 

_       _               PLUS    33 1 
                        LT      33 7 
                        SKIP    254 

_       _               ZERO    3 
                        PROCESS 11 
                        NEWLINE 
                        SYSMESS 7 
                        DONE    

_       _               SET     [2] 
                        SET     106 
                        COPYFF  3 104 
                        LET     117 1 
                        PROCESS 13 
                        COPYFF  109 33 

SUBIR   _               AT      16 
                        NOTCARR 11 
                        MESSAGE 14 
                        DONE    

BAJAR   _               AT      22 
                        NOTWORN 6 
                        NOTWORN 4 
                        MES     41 
                        MESSAGE 42 
                        DONE    

SALIR   _               AT      21 
                        NOTWORN 6 
                        NOTWORN 4 
                        MES     41 
                        MESSAGE 42 
                        DONE    

_       _               MOVE    38 

SALIR   _               AT      12 
                        CARRIED 13 
                        MESSAGE 24 
                        PLACE   13 19 
                        ANYKEY  

SALIR   _               AT      12 
                        CARRIED 12 
                        MESSAGE 25 
                        ANYKEY  

SALIR   _               AT      12 
                        CLS     

SUBIR   _               AT      22 
                        MES     26 
                        MES     27 
                        ANYKEY  

BAJAR   _               AT      16 
                        MES     26 
                        MES     28 
                        ANYKEY  

_       _               RESTART 

;------------------------------------------------------------------------------
/PRO 22

ENTRA   _               AT      13 
                        ZERO    141 
                        DONE    

ENTRA   _               AT      22 
                        ZERO    140 
                        DONE    

SUBIR   _               AT      22 
                        ZERO    140 
                        DONE    

;------------------------------------------------------------------------------
/PRO 23

_       _               PICTURE 25 
                        SFX     0 255 

_       _               MES     30 
                        PICTURE 27 
                        SFX     0 255 
                        ANYKEY  
                        CLS     
                        WORN    5 
                        WORN    4 
                        WORN    7 
                        WORN    3 
                        SKIP    1 

_       _               MESSAGE 31 
                        SYSMESS 75 
                        PROCESS 17 

_       _               NOTWORN 14 
                        MESSAGE 32 
                        SYSMESS 75 
                        PROCESS 17 

_       _               MES     33 
                        LET     100 36 
                        LET     101 39 
                        ISNOTAT 16 4 
                        LET     101 38 
                        ISAT    15 4 
                        LET     101 37 

_       _               NOTZERO 144 
                        LET     100 35 

_       _               ISNOTAT 17 4 
                        LET     100 34 

_       _               MES     [100] 
                        SPACE   
                        MES     [101] 
                        SYSMESS 78 
                        PROCESS 17 


;---------------------------------------------------------------------------
