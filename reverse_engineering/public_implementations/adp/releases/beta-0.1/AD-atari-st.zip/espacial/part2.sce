;---------------------------------------------------------------------------
;---------------------   An UnDAADed game o'hacker   -----------------------
;---------------------------------------------------------------------------
; DAAD Vers. : 2
; Target     : ST (5)
; Language   : Spanish (1)
; BaseAddr   : 0x0000
; Endianness : Little-endian
; Null Word  : _
;---------------------------------------------------------------------------
; Number of objects         : 22
; Number of Locations       : 21
; Number of User Messages   : 149
; Number of System Messages : 179
; Number of Processes       : 51
;---------------------------------------------------------------------------
;                   Memory   File 
; Pointer            Addr   Offset
; =======           ======  ======
; Tokens addr     : 0x0293  0x0293
; Procs addr      : 0x56BA  0x56BA
; Objs addr       : 0x3408  0x3408
; Locs addr       : 0x3972  0x3972
; UsrMsg addr     : 0x3220  0x3220
; SysMsg addr     : 0x0B9E  0x0B9E
; Connex addr     : 0x39C6  0x39C6
; Vocabu addr     : 0x00FC  0x00FC
; InitAt addr     : 0x3A5E  0x3A5E
; ObjName addr    : 0x39F0  0x39F0
; Weight/CW addr  : 0x3A1C  0x3A1C
; Extra attr addr : 0x3A32  0x3A32
;---------------------------------------------------------------------------
; File length    : 0x5720 (22304 bytes)
;---------------------------------------------------------------------------
;
;
/CTL
_
/TOK
_de_
a_de_
_est�
s_de_
_la_
_el_
_te_
_un_
as_
_de
os_
es_
ado
ent
_co
ero
a_
o_
e_
ar
es
er
an
a.
en
al
as
di
,_
or
n_
id
el
ci
nt
ad
s_
".
qu
l_
..
y_
ur
os
o.
re
am
ch
ll
te
pu
�n
on
in
ro
ti
Es
ab
ri
ac
at
t�
tu
mp
gu
ed
:_
av
ir
._
un
ol
ce
su
to
um
ag
ca
tr
is
pi
po
ra
et
om
li
ug
Un
ev
m�
_s
ta
de
us
Ta
_n
la
si
ha
cl
it
mu
vi
!"

se
ez
_l
ob
cu
eb
aj
co
_m
�n
_p
do
lu
ni
bu
ec
le
fi
ig
En
ru
hu
.
;------------------------------------------------------------------------------
/VOC    ;Vocabulary
ABRIR   61      verb
ALMAC   67      verb
ANTLI   103     noun
BAJAR   4       verb
BOTAS   81      noun
BURBU   74      noun
CAMPO   61      noun
CARIN   104     noun
CARLI   3       verb
CASCO   63      noun
CERRA   62      verb
CHIP    78      noun
COGER   59      verb
COMPU   60      noun
DEJAR   60      verb
DIAPA   73      noun
ENTRA   1       verb
ESCUC   55      verb
ESPER   53      verb
EXAMI   58      verb
FIN     70      verb
GUANT   65      noun
HABLA   56      verb
HIBER   69      noun
INSTR   80      noun
INVEN   52      verb
JUGAD   68      verb
LEGIO   69      verb
LIRAE   105     noun
LLAVE   75      noun
LOADD   52      noun
METER   65      verb
MIRAR   54      verb
NUCLE   72      noun
OB6     66      noun
OB7     67      noun
OB8     68      noun
PI      101     verb
PLACA   64      noun
PONER   63      verb
PRISM   79      noun
PSI     102     verb
PUERT   70      noun
PULVE   76      noun
QUITA   64      verb
RAMLO   53      noun
RAMSA   51      noun
SACAR   66      verb
SALID   51      verb
SALIR   2       verb
SAVED   50      noun
SOBRE   77      noun
SUBIR   5       verb
TARJE   71      noun
TAU     100     verb
TODO    49      noun
TRAJE   62      noun
USAR    57      verb
;------------------------------------------------------------------------------
/STX    ;System Messages Texts
/0 
PASA A BAJA RESOLUCION.
/1 
Adem�s hay 
/2 
\r>
/3 
0
/4 
. 
/5 
No hay ning�n sitio donde se pueda meter nada.\r
/6 
La entrop�a del universo aumenta inexorablemente.\r
/7 
No hay ninguna salida.\r
/8 
No puedes 
/9 
Tienes 
/10 
No tienes nada de nada.\r
/11 
Tienes puesto 
/12 
�Seguro? (S/N) 
/13 
Est� cerrada.\r
/14 

/15 
Vale.\r
/16 

/17 
\rTurnos consumidos: 
/18 
No ha lugar.\r
/19 
Tendr�s que quitarte algo antes de ponerte _.\r
/20 
.\r
/21 

/22 

/23 
Se puede poner.\r
/24 
Llevas _.\r
/25 

/26 

/27 
Ya no puedes llevar m�s trastos.\r
/28 
ponerte.\r
/29 
quitarte.\r
/30 
S
/31 
N
/32 
--->
/33 

/34 
abrir nada.\r
/35 
Est� abierto.\r
/36 
Has cogido _.\r
/37 
Te has puesto _.\r
/38 
Te has quitado _.\r
/39 
Has dejado _.\r
/40 
No puedes ponerte _.\r
/41 
No puedes quitarte _.\r
/42 
Llevas demasiadas cosas, no puedes quitarte _.\r
/43 
@ pesa demasiado.\r
/44 
@ est� en 
/45 
sacar.\r
/46 
, 
/47 
 y 
/48 
.\r
/49 
Dentro hay 
/50 
En el bolsillo hay 
/51 
.\r
/52 
coger.\r
/53 
dejar.\r
/54 
hacerlo.\r
/55 
\rNo hay nada para 
/56 
Disco no preparado. Pulsa una tecla para repetir.\r
/57 
Error de entrada/salida.\r
/58 
Disco lleno.\r
/59 
Nombre err�neo.\r
/60 
Nombre del fichero: 
/61 

/62 
Ya lo estaba.\r
/63 
Est� cerrado.\r
/64 
No hay ning�n sitio de donde sacar.\r
/65 
No tienes nada que puedas meter.\r
/66 
mover _.\r
/67 
cerrar nada.\r
/68 
Nunca pensaste que pudieras echar de menos los servomecanismos y las supercomputadoras del Anillo Dorado que tanto te hab�an fasti- diado hasta ahora.\r
/69 
Observas desilusionado que vuelves al feo h�bito del soliloquio.\r
/70 
No hay nada que utilizar.\r
/71 
Est� abierta.\r
/72 
@ 
/73 
no cabe en _.\r
/74 

/75 
Est�s muerto.\r
/76 
         
/77 
\".
/78 
\".\r
/79 
SALIDAS
/80 
INVENTARIO
/81 
ESPERAR
/82 
MIRAR
/83 
ESCUCHAR
/84 
HABLAR
/85 
USAR
/86 
EXAMINAR
/87 
COGER
/88 
DEJAR
/89 
ABRIR
/90 
CERRAR
/91 
PONERSE
/92 
QUITARSE
/93 
METER EN
/94 
SACAR DE
/95 
SAVE/LOAD
/96 
JUGADAS
/97 
ESPACIAL
/98 
FIN JUEGO
/99 

/100 
TODO
/101 
CONTINUAR
/102 
OTRA PART.
/103 
ADIOS
/104 
SAVE DISCO
/105 
SAVE RAM
/106 
LOAD DISCO
/107 
LOAD RAM
/108 
UA-E-VEECO
/109 
CAFU
/110 
UPM-CO
/111 
UPS-CO
/112 
SERPO
/113 
UPP-MN
/114 

/115 

/116 

/117 
COSASU
/118 
PUERTA
/119 
TIGA
/120 
DIPAS
/121 
ELSON
/122 
UVIR
/123 
MAGOLLA
/124 
MAPUL
/125 
PD-AA
/126 
CHAPO
/127 
PRILU
/128 
HODOSE
/129 
UPI-CO
/130 
ENTRAR
/131 
SALIR
/132 
CARLINGA
/133 
BAJAR
/134 
SUBIR
/135 
UA-VACU
/136 
VEECO
/137 

/138 

/139 
PANELES
/140 
CAJA
/141 
CRISTALES
/142 
SECUENCIA
/143 

/144 

/145 
RAMAUT
/146 
FOCOEX2
/147 
SERPOS
/148 
UA-E
/149 
CUPULA
/150 
BLANDURO
/151 
SER ALADO
/152 
CANTICOS
/153 
LEGAMO
/154 
SAURIOS
/155 

/156 

/157 
ROJO
/158 
AMARILLO
/159 
VERDE
/160 
AZUL
/161 
VIOLETA
/162 
NARANJA
/163 
BLANCO
/164 
GRIS
/165 
NIPROSTATO
/166 
BUTAZONITO
/167 
METAFAZOSO
/168 
SULF�DRICO
/169 
OXIL�TICO
/170 
MESKINATO
/171 
FLATOPASTO
/172 
GASNURITO
/173 
MZ-5
/174 
XI-KA+
/175 
ROMI
/176 
NIMBUS
/177 
DINUS
/178 
PIRITO
;------------------------------------------------------------------------------
/MTX    ;Message Texts
/0 
\b\rEsta es la segunda parte de la psicod�lica aventura gal�ctica \"La CONGA contra el CELO\", creada por el equipo A.D. en un per�odo de sobredosis.\k\b\rDirecci�n: Andr�s Samudio\rProgramaci�n: Juan Manuel Medina\rGr�ficos 16 bits: J. A. Darder\rGr�ficos 8 bits: Carlos Marqu�s\rCols: Eva Samitier, Tim Gilberts y Juanjo Mu�oz.\k\bSi necesitas ayuda para resolver esta aventura o cualquier otra, tienes dudas sobre el manejo del P.A.W., deseas tener noticias sobre lo que se cuece en el mundo de la aventura o tener acceso a aventuras exclusivas entonces ponte en contacto con...\k\b\rClub de Aventuras A.D. (C.A.A.D.)\r\rEscribe al Apdo. 319, 46080 de Valencia y obtendr�s cumplida informaci�n sobre el C.A.A.D. y su fanzine.
/1 
-
/2 
0
/3 
\r       OPCION DENEGADA
/4 
\r  UA-E EXTERIORES ABIERTAS
/5 
\r    UA-E DEPOSITO ABIERTA
/6 
\r        UA-E CERRADAS
/7 
    SECUENCIA DE DESPEGUE\r\r          ACTIVADA
/8 
   SECUENCIA DE APROXIMACION\r\r           ACTIVADA
/9 
   MANIOBRA DE APROXIMACION\r\r         EN PROGRESO
/10 
\r   CONTACTO CON SUPERFICIE
/11 
\r     ESTAMOS EN
/12 
\r  INTERIOR DEL ANILLO DORADO
/13 
\r   X   Y   Z     X   Y   Z\r    ORIGEN        DESTINO
/14 
ERR 
/15 
\rSALTO HIPERESPACIAL ACTIVADO
/16 
\r   COMUNICADO DE LA BASE
/17 
\r�REUNASE CON SUS SUPERIORES!
/18 
   COMUNICADO DEL CRUCERO\r\r     IMPERIAL VICTORIA
/19 
\r      ATAQUE DE VESUCOS
/20 
\r    �CA�ONES EN POSICION!
/21 
\r          �FUEGO!
/22 
\r           �BLANCO!
/23 
\r      IMPACTO RECIBIDO
/24 
\r  SE INICIA AUTORREPARACION
/25 
\r  AUTORREPARACION COMPLETA
/26 

/27 
+
/28 
-
/29 
�
/30 
%%%%%%%%%%%%%\r%%%%%%%%%%%%%\r%%%%%%%%%%%%%\r%%%%%%%%%%%%%\r%%%%%%&%%%%%%\r%%%%%%%%%%%%%\r%%%%%%%%%%%%%\r%%%%%%%%%%%%%\r%%%%%%%%%%%%%
/31 
*
/32 
%
/33 
&
/34 
\rAgotados todos sus escudos, tu VEECO se desintegra en una espectacular explosi�n. Eres ya un COMUCO.\k\b\rCOMUCO = Comando Muerto en Combate.
/35 
\rTe aproximas a la OSCURA AMENAZA. En pocos momentos proceder�s a la reanimaci�n y transmutaci�n de los COPOYOS a la superficie de la OSCURA AMENAZA.\r\rLa MIFI va a comenzar.\k\b\rORDENES-CLAVE: CANES VENATICI
/36 
ORDENES-CLAVE:
/37 
Al contacto con la TIGA, el meca- nismo del OPTOLOCK se activa y la UA-E-VEECO se abre.
/38 
Al contacto con tu mano, el CHAPO vibra. Sientes un raro cosquilleo.
/39 
Con un suave \"Puff\", el PD-AA se desmoleculariza al penetrar aire en su interior.
/40 
Un HODOSE se forma en el interior del PD-AA.\k\bPronto el HODOSE comienza parpa- dear y a desvanecerse.
/41 
En cuesti�n de segundos el HODOSE se apaga y el PD-AA se demolecula- riza en tus manos.
/42 
Con tus torpes manipulaciones la UVIR explota, decorando el paisaje con tus MUSAVIS.
/43 
�Error garrafal!. Has anulado los sistemas de soporte vital de tu traje y pronto te encuentras dando graciosas BOTIPESECS.\k\bBOTIPESECS: Boqueadas Tipo Pez en Secano.
/44 
Has dejado a 
/45 
 en Animaci�n Suspendida, sus mol�culas pasan directamente al DEPO de tu VEECO.
/46 
\r        �ENHORABUENA!\r\rCONTACTO CON COPOYOS POSITIVO.\r\r      PROCEDA FASE FINAL.\r\r         SIGUEN INSTRUCCIONES\k\b\r  1-NUEVAS COO: HCL MED QBD\r  2-NUEVA MISION: DESTRUCCION\r    CELO DE LA OA.\r  3-COPOYOS SACRIFICABLES.\r  4-DETECTADO AUMENTO EN LA\r    CONCENTRACION DE VESUCOS.\r\r------------SUERTE------------
/47 
Active secuencia crom�tica.
/48 
Los p�treos devuelven secuencias de color con 
/49 
un tono marr�n y dos blancos.
/50 
dos tonos marr�n y uno blanco.
/51 
tres tonos marr�n.
/52 
\k\bUn Petreo se desprende de la formaci�n rocosa y se te aproxima.
/53 
Los angelicales vibrocantan en tono m�s bajo.
/54 
Los angelicales vibrocantan en tono m�s alto.
/55 
Un refulgente angelical cesa en sus evoluciones a�reas y se te acerca.
/56 
Active emisi�n olfativa.
/57 
Los saurios contraen sus bolsas gaseosas y emiten 
/58 
un olor f�tido y dos arom�ticos.
/59 
dos olores f�tidos y uno arom�tico.
/60 
tres olores altamente apestosos.
/61 
\bUn pesado Saurio sale de su charco y se te aproxima.
/62 
DUROLITIA
/63 
TECNODIA
/64 
PARADISO
/65 
VIPERIA
/66 
Has vuelto al Anillo Dorado.\k\bSaliste como un COSME, deb�as volver como un orgulloso CORME; pero ahora eres un vulgar COFRATO.\rSeg�n normas de la CONGA acabas de ganarte el pase al rango de BG.      (Tu m�s secreta ilusi�n).
/67 
Frente a un grupo de SERPOS.
/68 
Est�n inactivados.
/69 
BIPBOPBIPBOPBOPBIPBOPBOP BOPBOPBOPBOPBIPBIPBIPBOP BOPBIPBOPBOPBIPBIPBOPBOP
/70 
Oyes el zumbido de los sistemas de soporte vital de tu UPM-CO.
/71 
Una descarga de alta tensi�n pro- veniente del maltratado ZOCHA aca- ba con tu triste sino.
/72 
El SERPO se inactiva.
/73 
El MZ-5 activado entra en fase de Destrucci�n Urgente. Eres lo primero detectado y por consiguiente, eliminado.
/74 
La XI-KA+ se mueve y dice: COMUNICO ENTRADA EN SERVICIO.
/75 
El ROMI activado te limpia el polvo c�smico del traje mientras emite una y otra vez una curiosa secuencia de pitiditos no del todo carente de ritmo.
/76 
Intentas retirarle el CHAPO de la ZOCHA a la XI-KA+ y recibes una descarga el�ctrica como aviso.\k\bEste tipo de SERPO no es desactivable hasta que no haya cumplido su misi�n.
/77 
En su parte frontal hay una ZOCHA. 
/78 
Tiene un CHAPO insertado.
/79 
^
/80 
\k\bAlgunos p�treos empiezan a emitir vivos destellos rojizos.
/81 
\k\bEn alg�n sitio se activa una alarma de detecci�n de NO-SERPOS.
/82 
\r\k\bEl c�ntico de los angelicales ya no es tan mel�dico como antes.
/83 
\k\bHas logrado atraer la atenci�n de un buen n�mero de saurios que parecen  encontrarte bastante interesante.
/84 
\k\bLos destellos se est�n volviendo de un rojo sangre y son cada vez m�s frecuentes.
/85 
\k\bOyes un r�tmico golpeteo de metal contra metal. Parecen los pesados pasos de alg�n gigantesco SUPERSERPO.
/86 
\r\k\bLos angelicales vuelan en c�rculo sobre tu cabeza. La m�sica se ha convertido en  una sucesi�n de chillidos discordantes repetitivos.
/87 
\k\bCada vez aparecen m�s saurios que se te acercan lentamente y sin quitarte  ojo.
/88 
\k\bDe repente, varios p�treos, envueltos en un vivo fulgor escarlata, gravitan violentamente hacia t�.\k\bAntes de que puedas esquivarlos quedas enterrado bajo un mont�n de rocas relucientes.
/89 
\k\bUna UA-E se abre y tienes ante ti nada menos que a un TERMINATOR.\k\bMostrando un total desprecio hacia la Primera ley de la Rob�tica, te enfoca con su l�ser.\k\bUn nanosegundo despu�s, eres un MOCAGALRA.\k\bMOCAGALRA = Mont�n de Caca Gal�ctica Radioactiva.
/90 
\r\k\bPronto los chillidos adquieren un tono tan agudo que tu UPS-CO comienza a resquebrajarse.\k\bEl aire del planeta penetra por las grietas y en un par de minutos has muerto BOBESU.\k\bBOBESU = boqueando como un besugo...
/91 
\k\bLos irritados saurios te rodean.\k\bPoco a poco van estrechando el c�rculo.\k\bCinco minutos despu�s reposas en los est�magos de al menos una docena de ellos.
/92 
Unidad de Aislamiento Estanco ZOCONEX-ZOCACO. Ahora sellada hasta que el VEECO haya abandonado la Base A.D.
/93 
Es el Vehiculo Espacial de Exploraci�n y Combate asignado a tu misi�n.
/94 
{
/95 
|
/96 
Son tu garant�a de seguridad. Producen, conservan y controlan los escudos de antimateria que rodean y protegen tu VEECO.
/97 
Alberga el acumulador energ�tico estelar y los controles hiper- temporales que capacitan al VEECO para el SAHI.
/98 
Son los Petrus Ps�quicus, seres que controlan este planeta.
/99 
Son destellos de frecuencias crom�ticas en grupos de tres, sirven de medio de comunicaci�n a los Petrus.
/100 
}
/101 
~
/102 
Es una Rampa Magn�tica Autom�tica. Penetra a trav�s del FOCOEX hasta una zona de almacenamiento intermedio.
/103 
Fortaleza de Contacto con el Exterior: Son instalaciones tan inmensas que  podr�an pasar por ciudades, pero que no son m�s que la punta del iceberg urbano  que se extiende bajo la superficie del planeta. En ellas se llevan a cabo las funciones de acceso, detecci�n y comunicaci�n que enlazan a los SERPOS con el  Mundo Exterior.
/104 
Seres Positr�nicos. Los hay de diferentes modelos.
/105 
Unidad de Aislamiento Deslizante. Firmemente cerrada.
/106 
Estructura t�pica de gran importancia en este planeta. Sirve a los nativos de lugar de reuni�n y para ejecutar sus danzas de apareamiento. En la parte superior hay una apertura de entrada y salida.
/107 
Es el material de construcci�n de los nativos. Se dice que es una especie de lodo muy maleable. Terminada una secci�n de la obra, la tribu se sienta alrededor y mediante especial�simas vibraciones vocales lo altera molecularmente haci�ndolo endurecer.
/108 
Son los ef�meros y cantarinos Ang�licus Vol�tiles.
/109 
Son vibrocantos de alt�simas frecuencias y rapid�simas variaciones. Pero al comunicarse los adaptan para cada especie.
/110 
Es el burbujeante y f�tido fango donde viven los Saurios.
/111 
Son robustos Saurius Pedorrus, amos del planeta.
/112 

/113 
Es un enorme MAZINGER, versi�n 5.4, pero todav�a en servicio.
/114 
Es una Ginecoide de Exploraci�n y Combate.
/115 
Es un Robot de Mantenimiento e Informaci�n.
/116 
Es un bello ejemplar de Ang�licus Vol�til. 
/117 
Es un fuerte ejemplar de Saurius Pedorrus.
/118 
Es un dur�simo ejemplar de Petrus Ps�quicus.
/119 
Unidad de Aislamiento Estanco de acceso a tu VEECO. A un lado hay un OPTOLOCK.
/120 
Es un Campo de Fuerza que ocupa toda la parte posterior del DEPO.
/121 
Unidad Protectora Media de Combate.
/122 
Unidad Protectora Superior de Combate.
/123 

/124 
Unidad Protectora Perif�rica de Manipulaci�n.
/125 

/126 

/127 

/128 
Contenedor de Seres en Animaci�n Suspendida. En una peque�a pantalla a su lado se lee:\r
/129 
Es una puerta que puedo poner en cualquier sitio para fastidiar.
/130 
Tarjeta de Identificaci�n Gal�ctica. Adaptada molecularmente a tu personalidad.
/131 
Digitalizador Prot�ico de Animaci�n Suspendida.
/132 
Electro Diapas�n.
/133 
Unidad Vital Respiratoria. Contiene O2.
/134 
Magneto Llave.
/135 
Magneto Pulverizador.
/136 
Porta Documento. Modelo Autodestrucci�n en Atmosfera. Cerrado.
/137 
Chip Activador Positr�nico.
/138 
Prisma Luminiscente.
/139 
\b   MISION COD. GA-3346-4E\r        AGENTE KK4465\r\r1- Contacte COPOYOS en coords.\r      LNM     UFD     UUY\r      EWQ     RTS     BOD\r      SWY     FCD     POI\r      OPK     IUO     YTX\k\b\r\r2- Espere nuevas instrucciones.\k\b
/140 
Unidad Protectora Inferior de Com- bate. Una para cada pie.
/141 
Aqu� est� 
/142 
Pirito
/143 
XI-KA+
/144 
Nimbus
/145 
Dinus
/146 
CONTENEDOR 
/147 
: LIBRE.
/148 
: OCUPADO.
;------------------------------------------------------------------------------
/OTX    ;Object Texts
/0 

/1 
un brillante CAFU central
/2 
una UPM-CO
/3 
una UPS-CO
/4 
Un ZOCHA
/5 
unas UPP-MN
/6 

/7 

/8 

/9 
un COSASU
/10 

/11 
una TIGA
/12 
un DIPAS
/13 
un ELSON
/14 
una UVIR
/15 
una MAGOLLA
/16 
un MAPUL
/17 
un PD-AA
/18 
un CHAPO
/19 
un PRILU
/20 
un HODOSE
/21 
unas UPI-CO
;------------------------------------------------------------------------------
/LTX    ;Location Texts
/0 
\r\r\r                     ESPACIAL\r\r              (La CONGA vs el CELO)\r\r\r         SEGUNDA PARTE : EXPLORANDO MUNDOS\r\r                     Direcci�n\r                  Andr�s  Samudio\r\r               Programaci�n y sonido\r                Juan Manuel Medina\r\r                     Gr�ficos\r                  Carlos Marqu�s\r                Juan Antonio Darder\r\r\r             (C) AVENTURAS A.D. -1990-
/1 

/2 

/3 

/4 

/5 

/6 

/7 

/8 

/9 

/10 
        Sector 0 - ZOCE\rDe la Zona de Contacto Exterior es de donde parten y llegan todas las misiones. La UA-V est� cerrada, separ�ndote de todo lo conocido y seguro. Frente a ti est� un reluciente VEECO
/11 

/12 
          DEPO - VEECO\rEl Dep�sito tiene gran importancia en un peque�o veh�culo. Es un estrecho lugar atiborrad de paneles defensores y material de vital importancia. A un lado hay una alargada caja negra supersellada
/13 
Este planeta est� formado por intrincados ca�ones p�treos que no conducen a ninguna parte. La ausencia de vegetaci�n es total. Entre las miles de formaciones minerales destacan unos bell�simos racimos de dur�simo cristal policromado semejante al cuarzo. Algunos emiten d�biles secuencias lum�nicas
/14 

/15 
Esta civilizaci�n de SERPOS, altamente tecnificada, ha preferido el subsuelo planetario como habitat permanenente. Est�s frente a una de sus zonas de acceso hacia la que desciende una RAMAUT desde la plataforma de aterrizaje
/16 
Es una especie de almac�n de reparaci�n y mantenimiento. Una zona bastante grande de la pared est� ocupada por una UA-E
/17 
PARADISO es famoso por las bellas c�pulas de Blanduro que se levantan en medio del agreste paisaje. Est�s frente a una de ellas
/18 
El interior de la c�pula parece un fresc de Miguel Angel donde bellos seres alados revolotean envueltos en un dorado resplandor compitiendo unos con otros en piruetas cada vez m�s arriesgadas al ritm de extra�os c�nticos
/19 
El hirviente magma Cret�cico depositado en humeantes charcos excavados en las inertes rocas sirve de habitat a los correosos seres de �sta civilizaci�n. Del p�trido l�gamo salen a curiosear unos grandes saurios
/20 

;------------------------------------------------------------------------------
/CON    ;Conections
/0
/1
/2
/3
/4
/5
/6
/7
/8
/9
/10
SUBIR 11
/11
/12
CARLI 11
/13
SUBIR 11
/14
/15
SUBIR 11
BAJAR 16
/16
SUBIR 15
/17
SUBIR 11
ENTRA 18
/18
SALIR 17
/19
SUBIR 11
/20
;------------------------------------------------------------------------------
/OBJ    ;Objects data
;obj.no  starts.at   weight    c w  5 4 3 2 1 0 9 8 7 6 5 4 3 2 1 0    noun    adjective
/0        NOT_CREATED  1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    COMPU   _ 
/1        12           1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    CAMPO   _ 
/2        WORN         48      Y Y  _ _ _ _ _ _ _ _ _ _ _ Y _ _ _ Y    TRAJE   _ 
/3        WORN         22      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    CASCO   _ 
/4        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y Y    PLACA   _ 
/5        WORN         6       _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    GUANT   _ 
/6        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    OB6     _ 
/7        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    OB7     _ 
/8        NOT_CREATED  1       Y _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    OB8     _ 
/9        12           1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ Y _ _    HIBER   _ 
/10       NOT_CREATED  1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y Y _ _    PUERT   _ 
/11       CARRIED      2       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    TARJE   _ 
/12       1            30      _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    NUCLE   _ 
/13       1            50      _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    DIAPA   _ 
/14       WORN         12      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ Y _ _ _    BURBU   _ 
/15       NOT_CREATED  1       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    LLAVE   _ 
/16       1            50      _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    PULVE   _ 
/17       2            3       _ _  _ _ _ _ _ _ _ _ _ _ _ _ Y _ Y _    SOBRE   _ 
/18       2            3       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ Y _    CHIP    _ 
/19       1            50      _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    PRISM   _ 
/20       NOT_CREATED  3       _ _  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    INSTR   _ 
/21       WORN         20      _ Y  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _    BOTAS   _ 
;------------------------------------------------------------------------------
/PRO 0

_       _               DESTROY 0 
                        DESTROY 4 
                        DESTROY 10 
                        NOTZERO 69 
                        PROCESS [69] 

_       _               AT      0 
                        PROCESS 6 
                        LET     148 25 
                        ABILITY 8 200 
                        SET     102 
                        DESC    0 
                        ANYKEY  
                        CLS     
                        GOTO    10 
                        PROCESS 20 
                        SET     249 
                        PROCESS 19 
                        RESTART 

_       _               CLEAR   28 
                        NOTZERO 0 
                        SET     28 

_       _               NOTAT   11 
                        WINDOW  0 
                        WINAT   0 0 
                        WINSIZE 14 99 
                        NOTEQ   60 105 
                        GFX     0 1 
                        GFX     0 4 
                        PICTURE [38] 
                        DISPLAY [28] 
                        GFX     0 0 
                        GFX     0 3 

_       _               NOTAT   11 
                        WINDOW  1 
                        WINAT   15 17 
                        WINSIZE 9 34 
                        MODE    0 
                        CLS     
                        ZERO    28 
                        DESC    [38] 
                        SYSMESS 20 
                        PROCESS 3 

_       _               PROCESS 1 
                        REDO    

;------------------------------------------------------------------------------
/PRO 1

_       _               PROCESS 2 
                        NOTZERO 71 
                        SKIP    2 

_       _               EQ      31 255 
                        PLUS    32 1 
                        CLEAR   31 
                        SKIP    1 

_       _               PLUS    31 1 

_       _               CLEAR   71 
                        AT      11 
                        CLS     
                        SET     126 
                        PROCESS 30 
                        REDO    

_       _               PROCESS 4 
                        PROCESS 21 
                        CARRIED 18 
                        NOTWORN 5 
                        ZERO    118 
                        SET     118 
                        MESSAGE 38 

_       _               REDO    

;------------------------------------------------------------------------------
/PRO 2

_       _               DESTROY 0 
                        DESTROY 10 
                        DESTROY 4 

_       _               AT      16 
                        PROCESS 39 

_       _               PRESENT 20 
                        ZERO    119 
                        DESTROY 20 
                        MESSAGE 41 

_       _               NOTZERO 119 
                        CLEAR   119 

;------------------------------------------------------------------------------
/PRO 3

_       _               LISTOBJ 

_       _               SET     72 
                        NOTAT   10 
                        NOTAT   13 
                        NOTAT   15 
                        NOTAT   17 
                        NOTAT   19 
                        CLEAR   72 

_       _               PROCESS 41 
                        NOTAT   12 
                        NOTAT   11 
                        PROCESS 34 

_       _               AT      10 
                        NOTZERO 128 
                        ANYKEY  
                        CLS     
                        MESSAGE 66 
                        PROCESS 17 

;------------------------------------------------------------------------------
/PRO 4

_       _               LET     111 51 
                        LET     112 70 
                        LET     3 79 
                        LET     94 1 
                        CLEAR   83 
                        PROCESS 8 
                        SYSMESS 2 

_       _               PROCESS 13 
                        COPYFF  86 33 
                        GT      33 66 
                        SET     71 

;------------------------------------------------------------------------------
/PRO 5

_       _               CLEAR   105 
                        CLEAR   106 
                        ZERO    81 
                        LET     2 167 

_       _               COPYOF  [105] 3 
                        EQ      3 255 
                        SKIP    4 

_       _               SETCO   [105] 
                        NOTEQ   102 255 
                        HASNAT  [102] 
                        SKIP    2 

_       _               SAME    3 97 
                        PROCESS 7 
                        SKIP    1 

_       _               EQ      97 249 
                        PRESENT [105] 
                        PROCESS 7 

_       _               PLUS    105 1 
                        SKIP    251 

_       _               SET     102 
                        ZERO    106 
                        ZERO    81 
                        PROCESS 11 
                        CLEAR   104 
                        NOTDONE 

_       _               NOTZERO 104 
                        GT      106 1 
                        LET     [2] 100 
                        PLUS    2 1 
                        SET     [2] 
                        PLUS    2 1 
                        PLUS    106 1 

_       _               SET     [2] 
                        ADD     106 81 
                        LET     94 1 
                        SET     83 
                        CLEAR   104 
                        PROCESS 13 
                        CLEAR   81 
                        SET     35 
                        LT      86 22 
                        SYNONYM _ COMPU 
                        ADD     86 34 
                        SETCO   [86] 
                        DONE    

_       _               EQ      86 255 
                        SYNONYM _ TODO  

;------------------------------------------------------------------------------
/PRO 6

_       _               HASNAT  247 
                        SYSMESS 0 
                        ANYKEY  
                        EXIT    0 

_       _               LET     254 254 
                        SFX     0 254 
                        NOTZERO 255 
                        LET     254 253 
                        CLEAR   255 

_       _               NOTEQ   255 29 
                        CLEAR   [255] 

_       _               PLUS    255 1 
                        SMALLER 255 254 
                        SKIP    254 

_       _               LET     53 64 
                        LET     42 2 
                        RESET   
                        WINDOW  2 
                        WINAT   15 2 
                        WINSIZE 8 12 
                        MODE    2 
                        PAPER   1 
                        WINDOW  4 
                        WINAT   15 28 
                        WINSIZE 9 21 
                        MODE    2 
                        WINDOW  6 
                        WINAT   4 27 
                        WINSIZE 9 13 
                        MODE    2 
                        WINDOW  7 
                        WINAT   0 0 
                        WINSIZE 100 100 
                        CLS     

;------------------------------------------------------------------------------
/PRO 7

_       _               LET     80 108 
                        ADD     105 80 
                        COPYBF  [2] 80 
                        PLUS    2 1 
                        COPYBF  [2] 105 
                        PLUS    2 1 
                        PLUS    106 1 

;------------------------------------------------------------------------------
/PRO 8

_       _               LET     2 167 
                        CLEAR   81 

_       _               COPYBF  [2] 3 
                        PLUS    2 1 
                        PLUS    3 1 
                        COPYBF  [2] 111 
                        PLUS    2 1 
                        PLUS    81 1 
                        BIGGER  112 111 
                        PLUS    111 1 
                        SKIP    255 

_       _               SET     [2] 

;------------------------------------------------------------------------------
/PRO 9

_       _               LT      87 10 

_       _               PRINT   87 

;------------------------------------------------------------------------------
/PRO 10

_       _               WINDOW  3 
                        WINAT   [94] 2 
                        WINSIZE 1 12 
                        PAPER   1 
                        INK     0 
                        NOTZERO 90 
                        PAPER   6 
                        INK     0 

_       _               CLS     
                        COPYFF  94 2 
                        MINUS   2 15 
                        COPYFF  2 87 
                        PLUS    87 1 
                        PROCESS 9 
                        SPACE   
                        ADD     2 2 
                        ADD     88 2 
                        COPYFF  [2] 3 

_       _               SYSMESS [3] 
                        SAVEAT  

;------------------------------------------------------------------------------
/PRO 11

_       _               WINDOW  2 
                        PRINTAT 7 0 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        NEWLINE 
                        WINDOW  1 
                        DONE    

;------------------------------------------------------------------------------
/PRO 12

_       _               WINDOW  3 
                        PLUS    82 1 
                        WINAT   23 2 
                        WINSIZE 1 13 
                        PICTURE 63 
                        EQ      80 99 
                        PICTURE 64 
                        MINUS   82 1 

_       _               DISPLAY 0 
                        EQ      80 99 
                        PLUS    89 1 
                        WINDOW  1 
                        DONE    

_       _               WINAT   [82] 2 
                        WINSIZE 1 12 
                        PAPER   1 
                        INK     0 
                        CLS     
                        PLUS    87 1 
                        PROCESS 9 
                        SPACE   
                        SYSMESS [80] 
                        SAVEAT  

_       _               PLUS    89 1 
                        PLUS    80 1 
                        WINDOW  1 
                        EQ      33 58 
                        PLUS    80 1 

;------------------------------------------------------------------------------
/PRO 13

_       _               LET     85 167 
                        COPYFF  81 84 
                        ZERO    83 
                        WINDOW  1 

_       _               CLEAR   89 
                        LET     82 14 
                        COPYFF  85 88 
                        CLEAR   87 
                        GT      81 8 
                        LET     84 8 

_       _               LT      [85] 255 
                        COPYFF  [85] 80 
                        PLUS    85 2 
                        PROCESS 12 
                        MINUS   84 1 
                        NOTZERO 84 
                        SKIP    255 

_       _               GT      81 8 
                        LET     80 99 
                        PROCESS 12 

_       _               PROCESS 14 
                        SAME    86 89 
                        PROCESS 11 
                        GT      81 8 
                        SKIP    1 

_       _               ADD     86 86 
                        ADD     88 86 
                        MINUS   86 1 
                        COPYFF  [86] 86 
                        WINDOW  1 
                        PROCESS 11 
                        DONE    

_       _               PROCESS 11 
                        LET     94 1 
                        NOTEQ   [85] 255 
                        SKIP    250 

_       _               REDO    

;------------------------------------------------------------------------------
/PRO 14

_       _               PLUS    94 14 

_       _               NOTAT   11 
                        SET     90 
                        PROCESS 10 

_       _               PROCESS 15 
                        ISNDONE 
                        SKIP    255 

_       _               AT      11 
                        SKIP    8 

_       _               CLEAR   90 
                        PROCESS 10 
                        WINDOW  1 

_       _               EQ      60 113 
                        GT      94 15 
                        MINUS   94 1 
                        SKIP    251 

_       _               EQ      60 113 
                        COPYFF  82 94 
                        SKIP    250 

_       _               EQ      60 97 
                        SMALLER 94 82 
                        PLUS    94 1 
                        SKIP    249 

_       _               EQ      60 97 
                        LET     94 15 
                        SKIP    248 

_       _               EQ      60 13 
                        MINUS   94 14 
                        COPYFF  94 86 
                        SKIP    7 

_       _               ZERO    93 
                        EQ      60 105 
                        PROCESS 11 
                        SET     71 
                        RESTART 

_       _               EQ      60 112 
                        GT      81 8 
                        COPYFF  89 86 
                        SKIP    6 

_       _               GT      60 47 
                        LT      60 58 
                        COPYFF  60 61 
                        CLEAR   60 
                        PLUS    61 10 
                        EQ      61 58 
                        LET     61 68 

_       _               NOTZERO 60 
                        SKIP    243 

_       _               LT      61 59 
                        SKIP    242 

_       _               GT      61 68 
                        SKIP    241 

_       _               COPYFF  61 86 
                        MINUS   86 58 

_       _               BIGGER  86 89 
                        SKIP    239 

_       _               COPYFF  86 94 
                        PLUS    94 14 
                        SET     90 
                        NOTAT   11 
                        EXTERN  2 0 

_       _               SAME    86 89 
                        GT      81 8 
                        DONE    

_       _               AT      11 
                        DONE    

_       _               PROCESS 10 
                        CLEAR   95 
                        CLEAR   90 
                        PROCESS 10 
                        CLEAR   93 
                        WINDOW  1 
                        ZERO    83 
                        SYSMESS [3] 
                        SPACE   

SACAR   _               SET     95 

METER   _               SET     95 

USAR    _               EQ      3 126 
                        AT      16 
                        SET     95 

_       _               GT      3 156 
                        LT      3 173 
                        SET     95 

_       _               NOTZERO 83 
                        SYSMESS [3] 
                        NOTZERO 95 
                        CLEAR   95 
                        SPACE   
                        DONE    

_       _               NOTZERO 83 
                        NEWLINE 

;------------------------------------------------------------------------------
/PRO 15

_       _               INKEY   
                        SKIP    2 

_       _               AT      11 
                        NOTZERO 136 
                        CHANCE  1 
                        CHANCE  25 
                        WINDOW  3 
                        PICTURE 57 
                        DISPLAY 0 
                        PICTURE 55 
                        DISPLAY 0 
                        PICTURE 53 
                        DISPLAY 0 
                        PICTURE [248] 
                        DISPLAY 0 
                        PICTURE 0 
                        SFX     0 255 
                        MINUS   148 1 
                        ZERO    148 
                        SFX     0 254 
                        WINDOW  3 
                        PICTURE 53 
                        DISPLAY 0 
                        PICTURE 54 
                        DISPLAY 0 
                        PICTURE 55 
                        DISPLAY 0 
                        PICTURE 56 
                        DISPLAY 0 
                        PICTURE 57 
                        DISPLAY 0 
                        PAUSE   20 
                        SET     125 
                        SET     249 
                        PROCESS 19 
                        WINDOW  1 
                        WINDOW  1 
                        CLS     
                        MESSAGE 34 
                        SYSMESS 75 
                        GOTO    0 
                        PROCESS 17 

_       _               NOTDONE 

_       _               BORDER  0 
                        EQ      60 13 
                        CLEAR   60 
                        DONE    

_       _               NOTZERO 151 
                        INKEY   
                        INKEY   

_       _               EQ      60 13 
                        LET     60 13 
                        DONE    

_       _               EQ      60 27 
                        LET     60 105 
                        DONE    

_       _               NOTZERO 60 
                        SKIP    4 

_       _               EQ      61 72 
                        LET     60 113 
                        DONE    

_       _               EQ      61 80 
                        LET     60 97 
                        DONE    

_       _               EQ      61 77 
                        LET     60 112 
                        DONE    

_       _               EQ      61 75 
                        LET     60 111 
                        DONE    

_       _               EQ      60 81 
                        LET     60 113 
                        DONE    

_       _               EQ      60 65 
                        LET     60 97 
                        DONE    

_       _               EQ      60 73 
                        LET     60 105 
                        DONE    

_       _               EQ      60 79 
                        LET     60 111 
                        DONE    

_       _               EQ      60 80 
                        LET     60 112 

_       _               EQ      60 109 
                        LET     60 13 

_       _               EQ      60 77 
                        LET     60 13 

_       _               EQ      60 32 
                        LET     60 13 

;------------------------------------------------------------------------------
/PRO 16

_       _               CLEAR   103 
                        DOALL   [97] 
                        WHATO   
                        NOTEQ   102 255 
                        HASNAT  102 
                        DONE    

_       _               PLUS    103 1 

;------------------------------------------------------------------------------
/PRO 17

_       _               SYSMESS 17 
                        DPRINT  31 
                        SYSMESS 20 
                        ANYKEY  

_       _               AT      0 
                        WINDOW  1 
                        CLS     

_       _               WINDOW  0 
                        PROCESS 19 
                        WINDOW  1 

_       _               SYSMESS 2 
                        LET     3 102 
                        CLEAR   111 
                        LET     112 1 
                        CLEAR   83 
                        PROCESS 8 
                        LET     94 1 
                        NOTZERO 253 
                        LET     [2] 107 
                        PLUS    2 1 
                        LET     [2] 2 
                        PLUS    2 1 
                        PLUS    81 1 
                        SET     [2] 

_       _               SET     93 
                        PROCESS 13 
                        EQ      86 1 
                        NEWLINE 
                        QUIT    
                        EXIT    0 

_       _               EQ      86 2 
                        RAMLOAD 252 
                        RESTART 

_       _               GOTO    0 
                        RESTART 

;------------------------------------------------------------------------------
/PRO 18

_       _               RANDOM  166 
                        MINUS   166 1 

_       _               BIGGER  166 2 
                        SUB     2 166 
                        SKIP    255 

;------------------------------------------------------------------------------
/PRO 19

_       _               GFX     0 1 
                        GFX     0 4 
                        WINDOW  3 
                        COPYFF  38 2 
                        EQ      125 10 
                        LET     2 43 

_       _               EQ      125 255 
                        LET     2 42 

_       _               WINAT   14 1 
                        WINSIZE 1 51 
                        PICTURE 33 
                        DISPLAY 0 
                        WINAT   24 16 
                        WINSIZE 1 35 
                        DISPLAY 0 
                        WINAT   23 2 
                        WINSIZE 1 13 
                        PICTURE 63 
                        DISPLAY 0 
                        WINAT   15 0 
                        WINSIZE 8 1 
                        PICTURE 32 
                        DISPLAY 0 
                        WINAT   15 15 
                        WINSIZE 9 1 
                        DISPLAY 0 
                        WINAT   15 52 
                        DISPLAY 0 
                        WINAT   14 0 
                        WINSIZE 1 1 
                        PICTURE 34 
                        DISPLAY 0 
                        WINAT   14 15 
                        PICTURE 62 
                        DISPLAY 0 
                        WINAT   23 15 
                        PICTURE 60 
                        DISPLAY 0 
                        WINAT   14 52 
                        PICTURE 36 
                        DISPLAY 0 
                        WINAT   23 0 
                        PICTURE 35 
                        DISPLAY 0 
                        WINAT   24 15 
                        DISPLAY 0 
                        WINAT   24 52 
                        PICTURE 37 
                        DISPLAY 0 
                        NOTEQ   60 105 
                        WINAT   0 0 
                        WINSIZE 14 37 

_       _               NOTZERO 249 
                        CLEAR   249 
                        PICTURE [2] 
                        DISPLAY 0 

_       _               GFX     0 0 
                        GFX     0 3 
                        WINDOW  3 
                        WINAT   24 0 
                        WINSIZE 1 14 
                        PAPER   0 
                        CLS     
                        WINDOW  2 
                        CLS     

;------------------------------------------------------------------------------
/PRO 20

_       _               CLS     
                        MESSAGE 36 
                        NEWTEXT 
                        PARSE   0 
                        REDO    

FIN     _               QUIT    
                        EXIT    0 

FIN     _               REDO    

_       _               CLS     
                        GT      33 99 
                        GT      34 99 
                        NOTEQ   33 255 
                        NOTEQ   34 255 
                        SKIP    1 

_       _               REDO    

TAU     _               DESTROY 18 

PI      _               SET     118 

_       ANTLI           DESTROY 17 
                        PLACE   15 2 

_       CARIN           DESTROY 17 

;------------------------------------------------------------------------------
/PRO 21

_       _               LET     94 1 
                        CLEAR   81 

COGER   _               COPYFF  38 97 
                        SET     104 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 52 
                        DONE    

COGER   TODO            DOALL   255 

COGER   _               HASAT   2 
                        SYSMESS 8 
                        SYSMESS 66 
                        DONE    

COGER   _               AUTOG   
                        DONE    

DEJAR   _               LET     97 254 
                        SET     104 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 53 
                        DONE    

DEJAR   TODO            DOALL   254 

DEJAR   _               AUTOD   
                        DONE    

PONER   _               LET     97 254 
                        SET     104 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 28 
                        DONE    

PONER   TODO            DOALL   254 

PONER   _               AUTOW   
                        DONE    

QUITA   _               LET     97 253 
                        SET     104 
                        PROCESS 5 
                        ISNDONE 
                        SYSMESS 55 
                        SYSMESS 29 
                        DONE    

QUITA   TODO            DOALL   253 

QUITA   _               AUTOR   
                        NOTAT   12 
                        PROCESS 34 

QUITA   _               DONE    

SACAR   _               AT      16 
                        ISAT    18 4 
                        CREATE  4 

SACAR   _               LET     97 249 
                        LET     102 31 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 64 
                        DONE    

SACAR   _               COPYFF  51 109 
                        COPYFF  51 97 
                        EQ      51 1 
                        ZERO    117 
                        NEWLINE 
                        SYSMESS 63 
                        DONE    

SACAR   _               PROCESS 16 
                        NOTZERO 103 
                        SET     104 
                        PROCESS 5 
                        NEWLINE 

SACAR   _               ZERO    103 
                        SYSMESS 55 
                        SYSMESS 45 
                        DONE    

SACAR   TODO            DOALL   [109] 

SACAR   CHIP            ZERO    118 
                        EQ      115 2 
                        MESSAGE 76 
                        DONE    

SACAR   CHIP            EQ      109 4 
                        CLEAR   76 
                        CLEAR   115 
                        DESTROY 4 
                        ZERO    118 
                        MESSAGE 72 

SACAR   _               AUTOT   [109] 
                        DONE    

USAR    _               LET     97 254 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 70 
                        DONE    

USAR    PRISM           AT      13 
                        ZERO    75 
                        PROCESS 35 

USAR    DIAPA           AT      18 
                        ZERO    77 
                        PROCESS 38 
                        DONE    

USAR    PULVE           AT      19 
                        ZERO    78 
                        PROCESS 36 

USAR    CHIP            AT      16 
                        SYNONYM METER CHIP  
                        LET     109 4 
                        SKIP    12 

USAR    NUCLE           NOTZERO 73 
                        COPYFF  73 2 
                        COPYFF  73 3 
                        PLUS    2 74 
                        EQ      [2] 1 
                        SET     [2] 
                        MES     44 
                        PLUS    3 141 
                        MES     [3] 
                        MESSAGE 45 
                        DONE    

USAR    TARJE           NOTZERO 72 
                        ZERO    116 
                        SET     116 
                        MESSAGE 37 
                        PICTURE 14 
                        SFX     0 255 
                        DONE    

USAR    _               SYSMESS 18 
                        DONE    

METER   _               AT      16 
                        CREATE  4 

METER   _               LET     97 249 
                        LET     102 31 
                        PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 5 
                        DONE    

METER   CAMPO           ZERO    117 
                        NEWLINE 
                        SYSMESS 63 
                        DONE    

METER   _               CLEAR   110 
                        HASAT   0 
                        SET     110 

METER   _               COPYFF  51 109 
                        DESTROY 4 
                        LET     97 254 
                        PROCESS 16 
                        NOTZERO 103 
                        SET     104 
                        PROCESS 5 

METER   _               ZERO    103 
                        NEWLINE 
                        SYSMESS 65 
                        DONE    

METER   TODO            DOALL   254 

METER   _               HASNAT  1 
                        NOTZERO 110 
                        NEWLINE 
                        SYSMESS 72 
                        SETCO   [109] 
                        SYSMESS 73 
                        DONE    

METER   _               SAME    51 109 
                        NEWLINE 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

METER   CHIP            EQ      109 4 
                        LET     167 173 
                        LET     168 1 
                        LET     169 174 
                        LET     170 2 
                        LET     171 175 
                        LET     172 3 
                        SET     173 
                        LET     81 3 
                        LET     94 1 
                        SET     83 
                        PROCESS 13 
                        NEWLINE 
                        COPYFF  86 115 
                        PUTIN   18 4 
                        ZERO    118 
                        LET     2 72 
                        ADD     115 2 
                        MESSAGE [2] 
                        EQ      115 1 
                        PROCESS 17 

METER   CHIP            EQ      115 2 
                        ZERO    118 
                        LET     76 1 
                        DONE    

METER   CHIP            EQ      109 4 
                        DONE    

METER   _               NEWLINE 
                        EQ      109 4 
                        MESSAGE 71 
                        PROCESS 17 

METER   _               AUTOP   [109] 
                        DONE    

ABRIR   _               LET     97 249 
                        LET     102 3 
                        NOTZERO 72 
                        CREATE  0 

ABRIR   _               PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 8 
                        SYSMESS 34 
                        DONE    

ABRIR   CAMPO           ZERO    117 
                        SET     117 
                        SYSMESS 35 
                        DONE    

ABRIR   COMPU           NOTCARR 11 
                        SYSMESS 8 
                        SYSMESS 54 
                        DONE    

ABRIR   COMPU           ZERO    116 
                        SET     116 
                        MESSAGE 37 
                        PICTURE 14 
                        SFX     0 255 
                        DONE    

ABRIR   BURBU           PICTURE 0 
                        SFX     0 255 
                        MESSAGE 42 
                        PROCESS 17 

ABRIR   SOBRE           DESTROY 17 
                        NOTAT   10 
                        MESSAGE 39 
                        DONE    

ABRIR   SOBRE           PLACE   20 254 
                        MESSAGE 40 
                        SET     119 
                        DONE    

ABRIR   _               SYSMESS 62 
                        DONE    

CERRA   _               LET     97 249 
                        LET     102 3 
                        NOTZERO 72 
                        CREATE  0 

CERRA   _               PROCESS 5 
                        ISNDONE 
                        NEWLINE 
                        SYSMESS 8 
                        SYSMESS 67 
                        DONE    

CERRA   CAMPO           NOTZERO 117 
                        CLEAR   117 
                        SYSMESS 63 
                        DONE    

CERRA   COMPU           NOTZERO 116 
                        CLEAR   116 
                        SYSMESS 15 
                        PICTURE 14 
                        SFX     0 255 
                        DONE    

CERRA   _               SYSMESS 62 
                        DONE    

EXAMI   _               PROCESS 22 
                        DONE    

ALMAC   _               LET     111 50 
                        LET     112 52 
                        LET     3 104 
                        NOTZERO 253 
                        LET     112 53 

ALMAC   _               SET     83 
                        PROCESS 8 
                        LET     94 2 
                        LET     94 2 
                        PROCESS 13 
                        COPYFF  86 34 

ALMAC   RAMSA           RAMSAVE 
                        SET     253 
                        SYSMESS 15 
                        ANYKEY  
                        LET     60 105 
                        RESTART 

ALMAC   SAVED           SAVE    2 
                        LET     60 105 
                        RESTART 

ALMAC   LOADD           ZERO    253 
                        LOAD    2 
                        CLEAR   253 

ALMAC   LOADD           NOTZERO 253 
                        LOAD    2 
                        SET     253 

ALMAC   RAMLO           RAMLOAD 252 

ALMAC   _               RESTART 

SALID   _               PROCESS 23 
                        DONE    

FIN     _               LET     3 101 
                        CLEAR   111 
                        LET     112 2 
                        SET     83 
                        PROCESS 8 
                        LET     94 1 
                        PROCESS 13 
                        EQ      86 1 
                        GOTO    0 
                        RESTART 

FIN     _               NOTZERO 86 
                        QUIT    
                        EXIT    0 

FIN     _               LET     60 105 
                        RESTART 

JUGAD   _               SYSMESS 17 
                        DPRINT  31 
                        SYSMESS 20 
                        DONE    

_       _               CLEAR   83 
                        PROCESS 11 
                        NEWLINE 

INVEN   _               PROCESS 11 
                        ZERO    1 
                        NOTWORN 5 
                        NOTWORN 2 
                        NOTWORN 3 
                        NOTWORN 21 
                        NOTWORN 14 
                        SYSMESS 10 
                        DONE    

INVEN   _               NOTZERO 1 
                        SYSMESS 9 
                        LISTAT  254 

INVEN   _               NOTWORN 5 
                        NOTWORN 2 
                        NOTWORN 3 
                        NOTWORN 21 
                        NOTWORN 14 
                        DONE    

INVEN   _               SYSMESS 11 
                        LISTAT  253 
                        DONE    

MIRAR   _               LET     60 105 
                        RESTART 

LEGIO   _               MESSAGE 0 
                        DONE    

ESPER   _               SYSMESS 6 
                        DONE    

ESCUC   _               EQ      73 2 
                        EQ      115 3 
                        ZERO    118 
                        MESSAGE 69 
                        LET     120 1 
                        DONE    

ESCUC   _               AT      10 
                        MESSAGE 70 
                        DONE    

ESCUC   _               SYSMESS 68 
                        DONE    

HABLA   _               SYSMESS 69 
                        DONE    

_       _               SYSMESS 8 
                        SYSMESS 54 

;------------------------------------------------------------------------------
/PRO 22

_       _               LET     2 167 
                        COPYFF  38 111 
                        ADD     111 111 
                        COPYFF  111 112 
                        PLUS    111 115 
                        PLUS    112 72 

_       _               COPYBF  [2] 111 
                        PLUS    2 1 
                        COPYBF  [2] 112 
                        PLUS    2 1 
                        PLUS    111 1 
                        PLUS    112 1 
                        LT      2 171 
                        SKIP    255 

_       _               LET     81 2 
                        EQ      73 2 
                        LET     111 173 
                        LET     112 113 
                        EQ      76 1 
                        AT      15 
                        LET     [2] 174 
                        PLUS    2 1 
                        COPYFF  115 112 
                        PLUS    112 112 
                        COPYBF  [2] 112 
                        PLUS    2 1 
                        SKIP    2 

_       _               AT      16 
                        COPYBF  [2] 111 
                        PLUS    2 1 
                        COPYBF  [2] 112 
                        PLUS    2 1 
                        PLUS    111 1 
                        PLUS    112 1 
                        GT      76 1 
                        EQ      111 174 
                        PLUS    111 1 
                        PLUS    112 1 

_       _               AT      16 
                        LT      111 176 
                        SKIP    254 

_       _               NOTZERO 72 
                        CREATE  0 

_       _               NOTZERO 73 
                        NOTEQ   73 2 
                        COPYFF  73 111 
                        PLUS    111 74 
                        EQ      [111] 1 
                        LET     [2] 178 
                        PLUS    2 1 
                        LET     [2] 118 
                        PLUS    2 1 
                        COPYFF  73 111 
                        COPYFF  73 112 
                        ATGT    14 
                        PLUS    111 173 
                        PLUS    112 113 
                        MINUS   2 2 
                        COPYBF  [2] 111 
                        PLUS    2 1 
                        COPYBF  [2] 112 
                        PLUS    2 1 

_       _               SET     [2] 
                        LET     97 249 
                        PROCESS 5 
                        DESTROY 0 
                        LT      86 22 
                        SKIP    2 

_       _               MES     [86] 
                        SPACE   
                        EQ      73 2 
                        GT      86 112 
                        LT      86 116 
                        MES     77 
                        MINUS   86 112 
                        SAME    86 115 
                        MESSAGE 78 
                        DONE    

_       _               NEWLINE 
                        DONE    

_       _               COPYFF  86 111 
                        PLUS    111 119 
                        MESSAGE [111] 
                        WHATO   
                        SET     113 
                        LET     114 50 
                        HASNAT  4 
                        LET     114 49 

_       HIBER           LET     2 1 

_       HIBER           MES     146 
                        PRINT   2 
                        COPYFF  2 3 
                        PLUS    3 74 
                        LET     70 147 
                        EQ      [3] 255 
                        LET     70 148 

_       HIBER           MESSAGE [70] 
                        LT      2 4 
                        PLUS    2 1 
                        SKIP    254 

_       CAMPO           ZERO    117 
                        SYSMESS 63 
                        CLEAR   113 

_       CAMPO           NOTZERO 117 
                        SYSMESS 35 

_       COMPU           ZERO    116 
                        SYSMESS 13 
                        CLEAR   113 

_       COMPU           NOTZERO 116 
                        SYSMESS 71 

_       _               NOTWORN [51] 
                        HASAT   23 
                        SYSMESS 23 

_       _               HASAT   31 
                        NOTZERO 113 
                        COPYFF  51 97 
                        PROCESS 16 
                        NOTZERO 103 
                        SYSMESS [114] 
                        LISTAT  [97] 

;------------------------------------------------------------------------------
/PRO 23

_       _               LET     33 1 
                        LET     3 0 
                        LET     2 167 

_       _               COPYFF  38 99 
                        PROCESS 24 
                        ISNDONE 
                        MOVE    99 
                        LET     80 129 
                        ADD     33 80 
                        COPYBF  [2] 80 
                        PLUS    2 1 
                        COPYBF  [2] 33 
                        PLUS    2 1 
                        PLUS    3 1 

_       _               PLUS    33 1 
                        LT      33 6 
                        SKIP    254 

_       _               ZERO    3 
                        PROCESS 11 
                        NEWLINE 
                        SYSMESS 7 
                        DONE    

_       _               SET     [2] 
                        SET     83 
                        COPYFF  3 81 
                        LET     94 1 
                        PROCESS 13 
                        COPYFF  86 33 

_       _               MOVE    38 
                        PRESENT 20 
                        DESTROY 20 
                        MESSAGE 41 
                        ANYKEY  

_       _               RESTART 

;------------------------------------------------------------------------------
/PRO 24

SUBIR   _               NOTZERO 72 
                        ZERO    116 
                        DONE    

;------------------------------------------------------------------------------
/PRO 25

_       _               WINDOW  3 
                        WINAT   18 12 
                        WINSIZE 3 29 
                        LET     2 4 
                        MODE    2 
                        PAPER   0 
                        INK     2 
                        CLS     

_       _               NOTZERO 122 
                        MES     [122] 
                        SPACE   
                        NOTEQ   122 19 
                        EXTERN  4 0 

_       _               EQ      122 19 
                        PICTURE 4 
                        SFX     0 255 

_       _               NOTZERO 122 
                        PAUSE   17 

_       _               NOTZERO 122 
                        CLS     
                        PAUSE   5 
                        MINUS   2 1 
                        NOTZERO 2 
                        SKIP    252 

_       _               NOTZERO 123 
                        MES     [123] 
                        SPACE   
                        NOTZERO 124 
                        MES     [124] 
                        SPACE   

_       _               CLEAR   122 
                        CLEAR   123 
                        CLEAR   124 

;------------------------------------------------------------------------------
/PRO 26

_       _               DONE    

;------------------------------------------------------------------------------
/PRO 27

_       _               DONE    

;------------------------------------------------------------------------------
/PRO 28

_       _               WINDOW  3 
                        SFX     2 254 
                        PICTURE 44 
                        LET     2 16 
                        LET     3 1 

_       _               WINAT   [2] 11 
                        WINSIZE [3] 32 
                        PAUSE   1 
                        DISPLAY 0 
                        NOTEQ   2 3 
                        MINUS   2 1 
                        PLUS    3 1 
                        SKIP    255 

;------------------------------------------------------------------------------
/PRO 29

_       _               WINDOW  3 
                        SFX     0 254 
                        WINAT   18 12 
                        WINSIZE 3 29 
                        CLS     
                        COPYFF  125 156 
                        PLUS    156 21 
                        LET     2 4 
                        LET     3 13 

_       _               GFX     0 1 
                        GFX     0 4 
                        WINAT   0 0 
                        WINSIZE [2] 54 
                        PICTURE [156] 
                        DISPLAY 0 
                        WINAT   [2] 11 
                        WINSIZE [3] 32 
                        PICTURE 44 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 
                        PLUS    2 1 
                        MINUS   3 1 
                        NOTEQ   2 16 
                        SKIP    255 

_       _               GFX     0 1 
                        GFX     0 4 
                        WINAT   0 0 
                        WINSIZE 16 54 
                        PICTURE [156] 
                        DISPLAY 0 
                        WINAT   15 0 
                        WINSIZE 1 54 
                        PICTURE 20 
                        DISPLAY 0 
                        WINAT   16 11 
                        WINSIZE 1 32 
                        PICTURE 44 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 
                        GFX     0 1 
                        GFX     0 4 
                        WINAT   15 0 
                        WINSIZE 2 54 
                        PICTURE 20 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 

;------------------------------------------------------------------------------
/PRO 30

_       _               NOTSAME 125 126 
                        WINDOW  0 
                        WINAT   0 0 
                        WINSIZE 15 99 
                        GFX     0 1 
                        GFX     0 4 
                        COPYFF  125 2 
                        PLUS    2 21 
                        PICTURE [2] 
                        DISPLAY 0 
                        WINAT   15 0 
                        WINSIZE 20 99 
                        PICTURE 20 
                        DISPLAY 0 
                        LET     2 57 
                        NOTEQ   86 4 
                        GFX     0 0 
                        GFX     0 3 

_       _               EQ      86 4 
                        PICTURE [2] 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 
                        EXTERN  1 0 

_       _               EQ      86 4 
                        PICTURE [2] 
                        DISPLAY 0 
                        PAUSE   2 
                        NOTEQ   2 45 
                        MINUS   2 1 
                        SKIP    255 

_       _               NOTSAME 125 126 
                        COPYFF  125 126 

_       _               GT      125 4 
                        COPYFF  125 2 
                        MINUS   2 5 
                        PLUS    2 45 
                        COPYFF  2 248 
                        PICTURE [2] 
                        DISPLAY 0 

_       _               NOTZERO 127 
                        CLEAR   127 
                        PICTURE 31 
                        SFX     255 0 
                        PAUSE   30 
                        LET     122 10 
                        PROCESS 25 

_       _               NOTZERO 116 
                        LET     122 6 
                        PROCESS 25 
                        CLEAR   116 

_       _               LT      125 5 
                        NOTZERO 125 
                        LET     123 11 
                        COPYFF  125 124 
                        PLUS    124 61 
                        PROCESS 25 

_       _               EQ      120 2 
                        SET     120 
                        PAUSE   50 
                        LET     122 18 
                        PROCESS 25 
                        WINDOW  3 
                        WINAT   1 0 
                        WINSIZE 10 30 
                        CENTRE  
                        CLS     
                        MESSAGE 46 
                        ANYKEY  
                        SET     126 
                        CLEAR   86 
                        REDO    

_       _               ZERO    125 
                        LET     123 12 
                        PROCESS 25 
                        NOTZERO 128 
                        PAUSE   150 
                        LET     122 16 
                        LET     123 17 
                        PROCESS 25 
                        SET     129 

_       _               EQ      120 255 
                        PLUS    74 2 

_       _               GT      125 4 
                        PROCESS 31 
                        GT      125 5 
                        NOTEQ   120 2 
                        CHANCE  [74] 
                        CLEAR   74 
                        SET     136 

_       _               NOTZERO 136 
                        LET     122 19 
                        PROCESS 25 
                        PROCESS 31 

_       _               LET     89 8 
                        PROCESS 14 
                        EXTERN  3 0 
                        EQ      86 8 
                        GT      125 4 
                        LET     122 3 
                        PROCESS 25 
                        REDO    

_       _               EQ      86 1 
                        LT      125 5 
                        ZERO    129 
                        LET     122 7 
                        PROCESS 25 
                        PAUSE   30 
                        PICTURE 31 
                        SFX     255 0 
                        PLUS    125 5 
                        SET     128 
                        PROCESS 26 
                        REDO    

_       _               EQ      86 3 
                        GT      125 4 
                        ZERO    136 
                        PRINTAT 0 16 
                        PROCESS 48 
                        COPYFF  157 133 
                        PRINTAT 0 20 
                        PROCESS 48 
                        COPYFF  157 134 
                        PRINTAT 0 24 
                        PROCESS 48 
                        COPYFF  157 135 
                        REDO    

_       _               SAME    130 133 
                        SAME    131 134 
                        SAME    132 135 
                        SKIP    1 

_       _               EQ      86 4 
                        GT      125 4 
                        ZERO    136 
                        PROCESS 32 
                        REDO    

_       _               EQ      86 8 
                        LET     122 4 
                        PROCESS 25 
                        ZERO    125 
                        GOTO    10 
                        PROCESS 33 

_       _               EQ      86 8 
                        COPYFF  125 2 
                        MINUS   2 1 
                        COPYFF  2 3 
                        ADD     2 2 
                        PLUS    2 13 
                        GOTO    [2] 
                        PROCESS 33 

_       _               ZERO    136 
                        PLUS    74 7 
                        EQ      86 7 
                        LET     122 5 
                        PROCESS 25 
                        GOTO    12 
                        PROCESS 33 

_       _               EQ      86 5 
                        NOTZERO 136 
                        CLEAR   136 
                        PROCESS 42 
                        SET     126 
                        REDO    

_       _               EQ      86 6 
                        LT      125 5 
                        LET     148 25 
                        LET     122 24 
                        PROCESS 25 
                        PICTURE 5 
                        LET     2 12 
                        PAUSE   30 

_       _               EQ      86 6 
                        LT      125 5 
                        SFX     0 255 
                        NOTZERO 2 
                        MINUS   2 1 
                        SKIP    255 

_       _               EQ      86 6 
                        LT      125 5 
                        PAUSE   30 
                        LET     122 25 
                        PROCESS 25 
                        REDO    

_       _               EQ      86 2 
                        GT      125 4 
                        LT      125 10 
                        ZERO    136 
                        MINUS   125 5 
                        LET     122 8 
                        PROCESS 25 
                        LET     122 9 
                        PROCESS 25 
                        LET     121 16 
                        SET     127 
                        PROCESS 27 
                        REDO    

_       _               LET     122 3 
                        SET     86 
                        PROCESS 25 
                        REDO    

;------------------------------------------------------------------------------
/PRO 31

_       _               LET     123 13 
                        PROCESS 25 
                        PRINTAT 0 2 
                        LET     2 130 

_       _               LT      [2] 100 
                        MES     2 
                        LT      [2] 10 
                        MES     2 

_       _               PRINT   [2] 
                        SPACE   
                        PLUS    2 1 
                        EQ      2 133 
                        PRINTAT 0 16 

_       _               NOTEQ   2 136 
                        SKIP    253 

;------------------------------------------------------------------------------
/PRO 32

_       _               LET     125 18 
                        EQ      133 0 
                        EQ      134 0 
                        EQ      135 0 
                        LET     125 5 

_       _               EQ      133 145 
                        EQ      134 196 
                        EQ      135 6 
                        LET     125 6 

_       _               EQ      133 93 
                        EQ      134 107 
                        EQ      135 134 
                        LET     125 7 

_       _               EQ      133 112 
                        EQ      134 85 
                        EQ      135 137 
                        LET     125 8 

_       _               EQ      133 140 
                        EQ      134 3 
                        EQ      135 61 
                        LET     125 9 

_       _               EQ      133 170 
                        EQ      134 193 
                        EQ      135 184 
                        EQ      120 255 
                        LET     125 10 

_       _               EQ      133 164 
                        EQ      134 14 
                        EQ      135 76 
                        EQ      75 255 
                        EQ      76 255 
                        EQ      77 255 
                        EQ      78 255 
                        EQ      120 1 
                        LET     120 2 
                        SET     136 

_       _               EQ      125 18 
                        CLEAR   126 

_       _               COPYFF  133 130 
                        COPYFF  134 131 
                        COPYFF  135 132 
                        LET     122 15 
                        PROCESS 25 
                        LET     2 45 
                        WINDOW  3 
                        EXTERN  0 0 

_       _               PICTURE [2] 
                        DISPLAY 0 
                        PAUSE   2 
                        NOTEQ   2 57 
                        PLUS    2 1 
                        SKIP    255 

_       _               NOTEQ   125 10 
                        DONE    

_       _               GFX     0 1 
                        GFX     0 4 
                        PICTURE 39 
                        DISPLAY 0 
                        PICTURE [2] 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 
                        EXTERN  1 0 

_       _               PICTURE [2] 
                        DISPLAY 0 
                        PAUSE   2 
                        NOTEQ   2 45 
                        MINUS   2 1 
                        SKIP    255 

_       _               PAUSE   30 
                        SET     249 
                        PROCESS 19 
                        WINDOW  1 
                        CLS     
                        INK     1 
                        MESSAGE 35 
                        GOTO    0 
                        PROCESS 17 

;------------------------------------------------------------------------------
/PRO 33

_       _               WINDOW  7 
                        CLS     
                        SET     249 
                        PROCESS 19 
                        RESTART 

;------------------------------------------------------------------------------
/PRO 34

_       _               WORN    3 
                        WORN    5 
                        WORN    14 
                        WORN    2 
                        WORN    21 
                        SKIP    1 

_       _               MESSAGE 43 
                        SYSMESS 75 
                        PROCESS 17 

_       _               AT      10 
                        DONE    

_       _               COPYFF  73 2 
                        PLUS    2 74 
                        EQ      [2] 1 
                        MES     141 
                        PLUS    2 67 
                        MES     [2] 
                        SYSMESS 20 
                        DONE    

_       _               AT      16 
                        PROCESS 40 

_       _               NOTZERO [2] 
                        DONE    

;------------------------------------------------------------------------------
/PRO 35

_       _               LET     158 241 
                        LET     159 3 

_       _               LET     2 7 
                        PROCESS 18 
                        COPYBF  [158] 166 
                        MINUS   159 1 
                        NOTZERO 159 
                        PLUS    158 1 
                        SKIP    255 

_       _               PROCESS 37 

;------------------------------------------------------------------------------
/PRO 36

_       _               LET     158 241 
                        LET     159 2 

_       _               LET     2 7 
                        PROCESS 18 
                        COPYBF  [158] 166 
                        PLUS    158 1 
                        LET     [158] 3 
                        MINUS   159 1 
                        NOTZERO 159 
                        SKIP    255 

_       _               PROCESS 37 

;------------------------------------------------------------------------------
/PRO 37

_       _               ZERO    69 
                        LET     69 37 
                        RESTART 

_       _               CLEAR   69 
                        LET     163 56 
                        LET     164 165 
                        LET     165 78 
                        AT      13 
                        LET     163 47 
                        LET     164 157 
                        LET     165 75 

_       _               PROCESS 11 
                        WINDOW  1 
                        MODE    2 
                        PROCESS 39 
                        MESSAGE [163] 
                        LET     238 244 
                        LET     162 3 

_       _               COPYFF  164 3 
                        CLEAR   111 
                        LET     112 7 
                        PROCESS 8 
                        LET     94 1 
                        SET     83 
                        PROCESS 13 
                        COPYBF  [238] 86 
                        COPYFF  86 2 
                        WINDOW  1 
                        PLUS    238 1 
                        MINUS   162 1 
                        NOTZERO 162 
                        SKIP    255 

_       _               LET     238 244 
                        LET     2 241 
                        LET     162 3 
                        COPYFF  162 161 

_       _               COPYFF  [2] 3 
                        SAME    [238] 3 
                        MINUS   161 1 

_       _               MINUS   162 1 
                        NOTZERO 162 
                        PLUS    2 1 
                        PLUS    238 1 
                        SKIP    254 

_       _               NOTZERO 161 
                        PLUS    163 1 
                        NEWLINE 
                        NEWLINE 
                        MES     [163] 
                        ADD     163 161 
                        MESSAGE [161] 
                        NEWLINE 
                        MINUS   163 1 
                        REDO    

_       _               PLUS    163 5 
                        MESSAGE [163] 
                        LET     [165] 1 
                        ANYKEY  
                        LET     60 105 
                        RESTART 

;------------------------------------------------------------------------------
/PRO 38

_       _               LET     158 233 
                        LET     159 4 
                        WINDOW  1 
                        CLS     
                        WINDOW  3 
                        PAPER   0 
                        WINAT   15 2 
                        WINSIZE 9 24 
                        GFX     0 1 
                        GFX     0 4 
                        PICTURE 40 
                        DISPLAY 0 
                        WINAT   14 1 
                        WINSIZE 1 51 
                        PICTURE 33 
                        DISPLAY 0 
                        WINAT   24 1 
                        WINSIZE 1 35 
                        DISPLAY 0 
                        WINAT   15 0 
                        WINSIZE 9 1 
                        PICTURE 32 
                        DISPLAY 0 
                        WINAT   14 0 
                        WINSIZE 1 1 
                        PICTURE 34 
                        DISPLAY 0 
                        WINAT   24 0 
                        PICTURE 35 
                        DISPLAY 0 
                        GFX     0 0 
                        GFX     0 3 

_       _               LET     2 1 
                        PROCESS 18 
                        COPYBF  [158] 166 
                        PLUS    158 1 

_       _               LET     2 9 
                        PROCESS 18 
                        COPYBF  [158] 166 
                        MINUS   159 1 
                        NOTZERO 159 
                        PLUS    158 1 
                        SKIP    255 

_       _               CLEAR   228 
                        CLEAR   229 
                        CLEAR   230 
                        CLEAR   231 
                        CLEAR   232 
                        LET     159 228 
                        WINDOW  4 

_       _               MODE    0 
                        PROCESS 39 
                        MODE    2 
                        WINDOW  3 
                        WINAT   18 13 
                        INK     3 
                        WINSIZE 2 7 
                        CLS     

_       _               LET     158 228 
                        LET     2 228 
                        PRINTAT 1 1 

_       _               SAME    158 159 
                        MES     79 
                        SKIP    1 

_       _               SPACE   

_       _               LT      158 232 
                        PLUS    158 1 
                        SKIP    253 

_       _               PRINTAT 0 0 
                        SPACE   
                        PRINTAT 0 1 

_       _               PRINT   [2] 
                        LT      2 232 
                        PLUS    2 1 
                        SKIP    255 

_       _               PRINTAT 0 0 
                        SPACE   

_       _               PROCESS 15 
                        ISNDONE 
                        SKIP    255 

_       _               EQ      60 113 
                        LT      [159] 9 
                        PLUS    [159] 1 

_       _               EQ      60 97 
                        NOTZERO [159] 
                        MINUS   [159] 1 

_       _               EQ      60 112 
                        PLUS    159 1 
                        GT      159 232 
                        LET     159 228 

_       _               EQ      60 111 
                        MINUS   159 1 
                        LT      159 228 
                        LET     159 232 

_       _               EQ      60 105 
                        PROCESS 19 
                        RESTART 

_       _               NOTEQ   60 13 
                        SKIP    242 

_       _               LET     2 228 
                        LET     158 233 
                        LET     160 5 

_       _               COPYFF  [2] 3 
                        SAME    [158] 3 
                        MINUS   160 1 
                        NOTZERO 160 
                        PLUS    2 1 
                        PLUS    158 1 
                        SKIP    255 

_       _               WINDOW  4 
                        ZERO    160 
                        CLS     
                        MESSAGE 55 
                        LET     77 1 
                        ANYKEY  
                        CLS     
                        LET     60 105 
                        PROCESS 19 
                        RESTART 

_       _               NEWLINE 
                        BIGGER  [158] 3 
                        MESSAGE 54 
                        SKIP    237 

_       _               MESSAGE 53 
                        SKIP    236 

;------------------------------------------------------------------------------
/PRO 39

_       _               MINUS   121 1 
                        COPYFF  73 2 
                        PLUS    2 79 
                        EQ      121 8 
                        MESSAGE [2] 
                        NOTAT   18 
                        NOTAT   16 
                        ANYKEY  

_       _               EQ      121 4 
                        PLUS    2 4 
                        MESSAGE [2] 
                        NOTAT   18 
                        NOTAT   16 
                        ANYKEY  

_       _               ZERO    121 
                        PLUS    2 8 
                        MESSAGE [2] 
                        SYSMESS 75 
                        ANYKEY  
                        PROCESS 19 
                        WINDOW  3 
                        PAPER   0 
                        WINDOW  1 
                        CLS     
                        PROCESS 17 

;------------------------------------------------------------------------------
/PRO 40

_       _               ZERO    76 
                        MESSAGE 67 

_       _               EQ      76 255 
                        DONE    

_       _               ZERO    115 
                        MESSAGE 68 
                        DONE    

;------------------------------------------------------------------------------
/PRO 41

_       _               CLEAR   73 
                        ATGT    12 
                        ATLT    15 
                        LET     73 1 

_       _               ATGT    14 
                        ATLT    17 
                        LET     73 2 

_       _               ATGT    16 
                        ATLT    19 
                        LET     73 3 

_       _               ATGT    18 
                        LET     73 4 

;------------------------------------------------------------------------------
/PRO 42

_       _               PROCESS 28 

_       _               LET     151 1 
                        CLEAR   150 
                        LET     2 99 
                        PROCESS 18 
                        COPYFF  166 137 
                        LET     2 180 
                        PROCESS 18 
                        COPYFF  166 138 
                        EQ      120 255 
                        LET     151 3 

_       _               PROCESS 47 
                        LET     2 99 
                        PROCESS 18 
                        COPYFF  166 139 
                        LET     2 180 
                        PROCESS 18 
                        COPYFF  166 140 

_       _               PROCESS 45 
                        PROCESS 46 
                        WINDOW  5 
                        COPYFF  137 2 
                        COPYFF  138 3 
                        LET     155 6 
                        PROCESS 43 
                        COPYFF  139 2 
                        COPYFF  140 3 
                        LET     155 11 
                        PROCESS 43 
                        PRINTAT 15 15 
                        CLEAR   3 
                        CLEAR   152 
                        PROCESS 25 
                        ZERO    143 
                        ZERO    145 
                        SET     152 
                        LET     123 20 
                        PROCESS 25 

_       _               WINDOW  5 
                        INK     15 

_       _               EQ      3 6 
                        INK     2 

_       _               EQ      3 14 
                        INK     1 

_       _               PLUS    3 1 
                        NOTSAME 3 148 
                        MES     29 
                        SAVEAT  
                        SKIP    253 

_       _               SPACE   
                        CLEAR   60 
                        PROCESS 15 

_       _               EQ      60 13 
                        PICTURE 2 
                        SFX     0 255 
                        NOTZERO 152 
                        PLUS    149 1 
                        PLUS    150 1 
                        PICTURE 1 
                        SFX     0 255 
                        SFX     0 255 
                        SFX     0 255 
                        SMALLER 150 151 
                        SKIP    248 

_       _               EQ      60 13 
                        NOTZERO 152 
                        PROCESS 29 
                        DONE    

_       _               EQ      60 112 
                        PLUS    137 1 
                        EQ      137 100 
                        CLEAR   137 
                        SKIP    4 

_       _               ZERO    137 
                        EQ      60 111 
                        LET     137 99 
                        SKIP    3 

_       _               EQ      60 111 
                        MINUS   137 1 
                        SKIP    2 

_       _               EQ      60 113 
                        LT      138 180 
                        PLUS    138 1 
                        SKIP    1 

_       _               EQ      60 97 
                        NOTZERO 138 
                        MINUS   138 1 

_       _               PROCESS 44 
                        SKIP    242 

;------------------------------------------------------------------------------
/PRO 43

_       _               PRINTAT [155] 21 
                        INK     2 
                        LT      2 10 
                        SPACE   

_       _               PRINT   2 
                        PRINTAT [155] 15 

_       _               EQ      3 90 
                        CLEAR   3 
                        SPACE   
                        SKIP    2 

_       _               LT      3 90 
                        LET     2 90 
                        SUB     3 2 
                        COPYFF  2 3 
                        MES     28 

_       _               GT      3 90 
                        MINUS   3 90 
                        MES     27 

_       _               LT      3 10 
                        SPACE   

_       _               PRINT   3 

;------------------------------------------------------------------------------
/PRO 44

_       _               PLUS    147 1 
                        ZERO    141 
                        ZERO    142 
                        SKIP    1 

_       _               LT      147 6 
                        DONE    

_       _               CLEAR   147 
                        COPYFF  149 3 
                        PLUS    3 1 
                        ADD     3 3 
                        ADD     3 3 
                        ADD     3 3 
                        ADD     3 3 
                        CHANCE  [3] 
                        LET     2 3 
                        PROCESS 18 
                        COPYFF  166 141 
                        PROCESS 18 
                        COPYFF  166 142 

_       _               EQ      141 2 
                        PLUS    139 1 
                        EQ      139 100 
                        CLEAR   139 

_       _               EQ      141 3 
                        ZERO    139 
                        LET     139 100 

_       _               EQ      141 3 
                        MINUS   139 1 

_       _               EQ      142 2 
                        PLUS    140 1 
                        EQ      140 181 
                        PROCESS 47 
                        LET     140 179 
                        LET     142 3 
                        PLUS    139 50 
                        GT      139 99 
                        MINUS   139 100 

_       _               EQ      142 3 
                        NOTZERO 140 
                        MINUS   140 1 
                        SKIP    1 

_       _               EQ      142 3 
                        ZERO    140 
                        PROCESS 47 
                        LET     140 1 
                        LET     142 2 
                        PLUS    139 50 
                        GT      139 99 
                        MINUS   139 100 

_       _               PROCESS 45 
                        PROCESS 46 
                        CHANCE  [3] 
                        CHANCE  50 
                        WINDOW  3 
                        PICTURE 57 
                        DISPLAY 0 
                        PICTURE 55 
                        DISPLAY 0 
                        PICTURE 53 
                        DISPLAY 0 
                        PICTURE [248] 
                        DISPLAY 0 
                        WINDOW  5 
                        PICTURE 0 
                        SFX     0 255 
                        MINUS   148 1 
                        ZERO    148 
                        SFX     0 254 
                        WINDOW  3 
                        PICTURE 53 
                        DISPLAY 0 
                        PICTURE 54 
                        DISPLAY 0 
                        PICTURE 55 
                        DISPLAY 0 
                        PICTURE 56 
                        DISPLAY 0 
                        PICTURE 57 
                        DISPLAY 0 
                        PAUSE   20 
                        SET     125 
                        SET     249 
                        PROCESS 19 
                        WINDOW  1 

_       _               ZERO    148 
                        CLEAR   60 
                        INKEY   
                        SKIP    255 

_       _               ZERO    148 
                        WINDOW  1 
                        CLS     
                        MESSAGE 34 
                        SYSMESS 75 
                        GOTO    0 
                        PROCESS 17 

;------------------------------------------------------------------------------
/PRO 45

_       _               BIGGER  137 139 
                        COPYFF  137 143 
                        SUB     139 143 
                        SET     144 
                        SKIP    1 

_       _               COPYFF  139 143 
                        SUB     137 143 
                        CLEAR   144 

_       _               GT      143 50 
                        LET     2 100 
                        SUB     143 2 
                        COPYFF  2 143 
                        COPYFF  144 2 
                        CLEAR   144 
                        ZERO    2 
                        SET     144 

_       _               LET     2 180 
                        COPYFF  138 3 
                        GT      143 25 
                        SUB     3 2 
                        COPYFF  2 3 

_       _               BIGGER  3 140 
                        COPYFF  3 145 
                        SUB     140 145 
                        SET     146 
                        SKIP    1 

_       _               COPYFF  140 145 
                        SUB     3 145 
                        CLEAR   146 

_       _               GT      143 25 
                        LET     2 180 
                        SUB     145 2 
                        COPYFF  2 145 

;------------------------------------------------------------------------------
/PRO 46

_       _               WINDOW  6 
                        LT      143 8 
                        LT      145 6 
                        SKIP    1 

_       _               DONE    

_       _               LET     2 7 
                        LET     3 5 
                        ADD     143 2 
                        NOTZERO 144 
                        SUB     143 2 
                        SUB     143 2 

_       _               ADD     145 3 
                        ZERO    146 
                        SUB     145 3 
                        SUB     145 3 

_       _               SAME    2 153 
                        SAME    3 154 
                        DONE    

_       _               LT      153 14 
                        LT      154 10 
                        MINUS   154 1 
                        MINUS   153 1 
                        PRINTAT [154] 0 
                        TAB     [153] 
                        INK     15 
                        MES     32 
                        PRINTAT 4 6 
                        MES     33 
                        SAVEAT  

_       _               COPYFF  2 153 
                        COPYFF  3 154 
                        LT      143 7 
                        LT      145 5 
                        MINUS   3 1 
                        MINUS   2 1 
                        PRINTAT [3] 0 
                        TAB     [2] 
                        SAVEAT  
                        INK     1 
                        MES     31 
                        BACKAT  

;------------------------------------------------------------------------------
/PRO 47

_       _               WINDOW  6 
                        PAPER   0 
                        INK     15 
                        PRINTAT 0 0 
                        MES     30 

;------------------------------------------------------------------------------
/PRO 48

_       _               SAVEAT  
                        LET     2 3 
                        MES     1 
                        MES     1 
                        MES     1 
                        BACKAT  

_       _               PROCESS 50 
                        GT      60 9 
                        SKIP    255 

_       _               COPYFF  60 157 
                        PRINT   157 
                        ZERO    157 
                        SAVEAT  

_       _               BACKAT  

_       _               PROCESS 50 
                        EQ      60 13 
                        SKIP    6 

_       _               GT      60 9 
                        SKIP    254 

_       _               PROCESS 49 
                        ADD     60 157 
                        PRINT   157 
                        ZERO    157 
                        SAVEAT  

_       _               BACKAT  

_       _               PROCESS 50 
                        EQ      60 13 
                        SKIP    2 

_       _               GT      60 9 
                        SKIP    254 

_       _               PROCESS 49 
                        ADD     60 157 
                        ZERO    157 
                        PRINT   157 

_       _               GT      157 200 
                        MES     14 
                        PICTURE 8 
                        SFX     0 255 
                        PAUSE   17 
                        BACKAT  
                        SPACE   
                        SPACE   
                        SPACE   
                        PAUSE   17 
                        BACKAT  
                        MINUS   2 1 
                        NOTZERO 2 
                        SKIP    255 

_       _               GT      157 200 
                        REDO    

_       _               NOTZERO 157 
                        PRINT   157 

_       _               SPACE   
                        SPACE   
                        EXTERN  5 0 

;------------------------------------------------------------------------------
/PRO 49

_       _               COPYFF  157 61 
                        ADD     157 157 
                        ADD     157 157 
                        ADD     157 157 
                        ADD     61 157 
                        ADD     61 157 

;------------------------------------------------------------------------------
/PRO 50

_       _               CLEAR   60 
                        INKEY   

_       _               EQ      60 13 
                        DONE    

_       _               GT      60 47 
                        LT      60 58 
                        MINUS   60 48 
                        DONE    

_       _               REDO    


;---------------------------------------------------------------------------
